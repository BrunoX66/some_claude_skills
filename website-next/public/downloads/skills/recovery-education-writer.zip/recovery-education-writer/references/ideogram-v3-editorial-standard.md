# Ideogram V3 Editorial Illustration Standard

## Overview

All blog article illustrations for sobriety.tools are generated using **Ideogram V3** with character references. This document defines the complete editorial standard — characters, prompt structure, style rules, and API configuration.

## API Configuration

```
Endpoint: POST https://api.ideogram.ai/v1/ideogram-v3/generate
Content-Type: multipart/form-data
Auth: Api-Key header
```

### Standard Fields

| Field | Value | Notes |
|-------|-------|-------|
| `aspect_ratio` | `16x9` | All blog images are 16:9 |
| `rendering_speed` | `DEFAULT` | Full quality |
| `magic_prompt` | `ON` | Ideogram's prompt enhancement |
| `num_images` | `1` | One at a time |
| `style_type` | `FICTION` (with char ref) or `GENERAL` (without) | **CRITICAL**: char refs require FICTION |
| `negative_prompt` | See below | Always include |

### Negative Prompt (Standard)

```
photorealistic, 3d render, ugly, deformed, blurry, watermark, text, words, labels, chibi, sexy, suggestive
```

### Style Suffix (Append to Every Prompt)

```
Warm color palette with teal, amber, and brown tones. Illustrated in a gentle, emotionally resonant style like a graphic novel. Cinematic framing, atmospheric lighting.
```

## The Five Characters

### Alex
- **Identity**: Latino, 20-22
- **Appearance**: Brown skin, dark curly hair, kind eyes, slightly tired expression
- **Wardrobe**: Teal hoodie `#4a9d9e`, dark jeans
- **Character sheet**: `alex-v3-sheet.png`
- **Seed**: 585079735
- **Use for**: Contradiction, executive function, impossible choices, harm reduction

### Jordan
- **Identity**: White, 20-22
- **Appearance**: Auburn hair (messy bun), freckles, warm but guarded expression
- **Wardrobe**: Oversized orange cardigan `#d97706`, cream t-shirt, dark leggings
- **Character sheet**: `jordan-v3-sheet.png`
- **Seed**: 1338109298
- **Use for**: Social dynamics, 12-step meetings, connection, alcohol articles

### Marcus
- **Identity**: Black, 21
- **Appearance**: Dark brown skin, short fade haircut, gentle but guarded expression, broad shoulders
- **Wardrobe**: Warm brown leather jacket, cream henley shirt, dark jeans
- **Character sheet**: `marcus-v3-sheet.png`
- **Seed**: 1335478625
- **Use for**: Clinical/institutional settings, neuroscience, treatment systems, opioid articles

### Mei
- **Identity**: East Asian, 20
- **Appearance**: Light skin, long straight dark hair (tucked behind ear), observant eyes, quiet intensity, slight default frown
- **Wardrobe**: Oversized sage green sweater, black leggings, small silver necklace
- **Character sheet**: `mei-v3-sheet.png`
- **Seed**: 671144309
- **Use for**: Introspection, self-medication, ADHD, cannabis articles

### Sofia
- **Identity**: Latina, 22
- **Appearance**: Warm olive skin, dark wavy hair past shoulders, determined expression with hint of vulnerability, strong jawline
- **Wardrobe**: Burgundy wine-colored hoodie, ripped jeans, small hoop earrings
- **Character sheet**: `sofia-v3-sheet.png`
- **Seed**: 1857459180
- **Use for**: Physical symptoms, withdrawal, sober living, body damage articles

### Character Sheet Location

```
/Users/erichowens/coding/jbuds4life/experiments/blog-image-styles/character-sheets/
├── alex-v3-sheet.png
├── jordan-v3-sheet.png
├── marcus-v3-sheet.png
├── mei-v3-sheet.png
└── sofia-v3-sheet.png
```

## Character Reference Rules

### USE character ref (FICTION style) when:
- The person IS the subject of the image
- The image conveys emotion through expression/body language
- The character is in a specific physical setting interacting with it

**Examples:**
- "Jordan sits alone at a dinner party while everyone drinks"
- "Marcus stares at a PET scan in a dark radiology room"
- "Sofia curled in fetal position on a hospital bed"

### DO NOT use character ref (GENERAL style) when:
- The image is a symbolic still life or object study
- No person is the subject (environments, abstract concepts)
- Hands/body parts with no face visible

**Examples:**
- "Two coffee cups on a table, one untouched"
- "Empty hospital bed with rumpled sheets"
- "Identical pills scattered on a dark surface"
- "Hands gripping the edge of a sink" (no face = no char ref)

### Why This Matters

Character references in FICTION style force the character's likeness into the scene. When used on symbolic images (coffee cups, empty rooms), Ideogram tries to insert the character's face where it doesn't belong — hiding the symbolic subject. The hybrid approach was learned through painful iteration (see experiments/blog-image-styles/index.html for the full decision history).

## Prompt Construction

### Anatomy of a Good Prompt

```
[Character description in their wardrobe] + [specific setting with lighting] + [emotional subtext] + [style suffix]
```

### Character Prompt Example

```python
f"A young Latina woman in a burgundy hoodie lying in a narrow hospital bed, blanket pulled tight, trembling slightly, dim bedside lamp, the body betraying itself. Warm color palette with teal, amber, and brown tones. Illustrated in a gentle, emotionally resonant style like a graphic novel. Cinematic framing, atmospheric lighting."
```

### Symbolic Prompt Example

```python
f"An empty hospital bed with rumpled white sheets, IV stand with no bag attached, harsh fluorescent lighting, institutional dread, no people. Warm color palette with teal, amber, and brown tones. Illustrated in a gentle, emotionally resonant style like a graphic novel. Cinematic framing, atmospheric lighting."
```

### Prompt Tips

1. **Always describe wardrobe colors** — the character sheets establish look, but prompt reinforces clothing
2. **"No people"** at end of symbolic prompts prevents unwanted human insertion
3. **Lighting is everything** — specify: "harsh overhead", "dim bedside lamp", "fluorescent", "warm amber", "cold blue"
4. **End with emotional subtext** — short phrase describing the feeling: "domestic devastation", "the body in revolt", "forensic stillness"
5. **Close-ups work well** — "extreme close-up", "macro detail shot", "ground-level perspective"

## Color Palette

| Color | Hex | Use |
|-------|-----|-----|
| Teal | `#4a9d9e` | Alex's hoodie, accent highlights |
| Ember Orange | `#d97706` | Jordan's cardigan, warm lighting |
| Leather Brown | `#2d2319` | Background tones, Marcus's jacket |
| Cream | `#fef3c7` | Light surfaces, henley shirts |
| Burgundy | wine tone | Sofia's hoodie |
| Sage Green | muted | Mei's sweater |

## Character Assignment Per Article Category

| Category | Primary Character | Secondary | Notes |
|----------|-------------------|-----------|-------|
| Stimulants | Alex | Marcus | Executive function, paranoia, impossible choices |
| Opioids | Marcus | Sofia | Clinical settings, withdrawal, body damage |
| Alcohol | Jordan | Mei | Social dynamics, isolation in crowds |
| Cannabis | Mei | — | Introspection, quiet dependency |
| Recovery | Jordan, Sofia | — | Meetings, sober living, physical healing |
| Harm Reduction | Alex | Sofia | Contradiction, survival |
| Neuroscience | Marcus | — | Clinical, institutional |
| Psychology | Mei | Alex | Self-medication, inner conflict |
| Relationships | Alex + Jordan | — | Paired scenes |

## Target Per Article

- **~2 character-driven images** (FICTION style with char ref)
- **~2 symbolic images** (GENERAL style, no char ref)
- **4 total images per standard article**
- **2 images for data articles** (that also have interactive charts)

## Output Format

- **Format**: PNG from API → convert to WebP for web
- **Naming**: `{article-slug}-{1,2,3,4}.webp` (inline) or `{article-slug}-hero.webp` (hero/OG)
- **Location**: `public/images/blog/inline/` and `public/images/blog/`
- **Image 1** of each article doubles as the hero/OG image

## API Key

Stored in environment. Check `.env.local` for `IDEOGRAM_API_KEY` or the experiments scripts.

## Generation Script Pattern

See `/Users/erichowens/coding/jbuds4life/experiments/blog-image-styles/scripts/gen-v3-final.py` for the production script pattern. Key features:

- Sequential generation (2s delay between calls)
- Skip existing files (idempotent re-runs)
- Multipart form-data construction for character reference upload
- Error handling with retry logging
- PNG download from returned URL

## Quality Checklist

Before shipping images:

- [ ] Character matches the sheet (right person, right wardrobe)
- [ ] No text/labels/watermarks in image
- [ ] Emotional tone matches article content
- [ ] Symbolic images don't accidentally include faces
- [ ] Lighting creates appropriate mood (not generic/flat)
- [ ] 16:9 aspect ratio maintained
- [ ] WebP conversion done at quality 85+
