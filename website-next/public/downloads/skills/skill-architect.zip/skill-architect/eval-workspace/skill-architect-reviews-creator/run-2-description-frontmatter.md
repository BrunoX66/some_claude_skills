# Description & Frontmatter Audit: skill-creator

**Reviewer**: skill-architect
**Target**: `/Users/erichowens/.claude/plugins/marketplaces/claude-plugins-official/plugins/skill-creator/skills/skill-creator/SKILL.md`
**Date**: 2026-03-06
**Audit scope**: Description field, frontmatter fields, and semantic activation properties

---

## Overall Score: 5/10

The description is *functional* but violates several core principles from the Description Formula and the description-guide reference. It leans toward a procedural laundry list rather than a semantic activation signal. The frontmatter is minimal (only `name` and `description`), which is defensible for a meta-skill but leaves activation precision opportunities on the table.

---

## 1. Description Analysis

### Current Description

```yaml
description: Create new skills, modify and improve existing skills, and measure skill performance. Use when users want to create a skill from scratch, update or optimize an existing skill, run evals to test a skill, benchmark skill performance with variance analysis, or optimize a skill's description for better triggering accuracy.
```

**Character count**: ~295 characters (within the 1024 limit)
**Word count**: ~48 words (within the 25-50 ideal range, barely)

### 1.1 Formula Compliance: `[What] [When to use] NOT [Exclusions]`

| Component | Present? | Assessment |
|-----------|----------|------------|
| **What it does** | Partial | "Create new skills, modify and improve existing skills, and measure skill performance." -- This is three verbs stitched together. It reads like a feature list, not a semantic purpose statement. Compare: "Guides the full lifecycle of creating, testing, and iterating on Claude Agent Skills" -- one coherent *what*. |
| **When to use** | Yes, but over-specified | The "Use when" clause enumerates five scenarios as a flat list. This is the "mini-manual" anti-pattern from the description guide (Example 3). Enumeration works for keyword matching, but the description guide explicitly states Claude evaluates **semantically**, not via keyword matching. A tighter semantic signal ("Use when building, testing, or iterating on any skill") would activate just as reliably without the list. |
| **NOT for [Exclusions]** | **Missing entirely** | This is the single biggest deficiency. The description guide calls this out as Anti-Pattern #2 and the scoring rubric penalizes skills without a NOT clause as 3-4 on Activation Precision. Without exclusions, this description will false-positive on: (a) general coding improvement requests, (b) performance benchmarking of non-skill systems, (c) "optimize a description" for non-skill content, (d) test/eval requests for non-skill code. |

**Formula compliance score**: 4/10 -- Has What and When, but missing NOT clause entirely. The What is a list rather than a coherent statement.

### 1.2 Semantic Activation Quality

The description guide's "Activation Strategy" section emphasizes three principles:

**A. Domain-specific semantic signals**

The description uses "skills", "evals", "benchmark", "variance analysis", "triggering accuracy" -- these are strong domain signals. However, some are overly specific process terms ("variance analysis") that belong in the SKILL.md body, not the activation description. A user is unlikely to say "run variance analysis on my skill"; they're more likely to say "is my skill working well?" or "test my skill."

Rating: 6/10 -- Good domain terms, but some are process-level rather than user-intent-level.

**B. Verb + Noun semantic signals**

The description has: "create skills", "modify skills", "improve skills", "measure performance", "run evals", "benchmark performance", "optimize description". This is *seven* verb-noun pairs in a single description. The description guide warns against catch-all descriptions (Example 7): "Becomes a generic [X] agent that competes with every other skill." Seven distinct capabilities is approaching catch-all territory.

However, this is a legitimate meta-skill with broad scope, so breadth is defensible. The fix is not to narrow the scope but to add clear exclusions to prevent bleeding into adjacent territory.

Rating: 5/10 -- Too many verb-noun pairs dilute the semantic signal. The description is trying to activate on everything skill-related, which is correct, but without exclusions it will also activate on things that merely *sound* skill-related.

**C. Synonym coverage**

The description covers "create" and "modify" and "improve" and "optimize" -- good synonym variety. But it misses common user phrasings like:
- "make a skill" (casual)
- "debug my skill" / "my skill isn't triggering" (troubleshooting)
- "write a SKILL.md" (artifact-specific)
- "turn this into a skill" (conversion intent)

The SKILL.md body at line 49 explicitly handles "turn this into a skill" as a use case, but the description doesn't cover this trigger phrase.

Rating: 5/10 -- Decent synonym coverage for creation, but misses troubleshooting and conversion phrasings that the skill body explicitly supports.

### 1.3 Anti-Query Analysis

Since the description has no NOT clause, let me enumerate queries that would likely false-positive:

| Anti-Query | Why it false-positives | Should trigger? |
|-----------|----------------------|-----------------|
| "Optimize the description text on my landing page" | Contains "optimize" + "description" | No -- marketing copy, not skill metadata |
| "Run performance benchmarks on my API" | Contains "benchmark" + "performance" | No -- system perf, not skill perf |
| "Create a new test for my function" | Contains "create" + "test" | No -- unit testing, not skill eval |
| "Improve my writing skills" | Contains "improve" + "skills" | No -- personal development, not Claude skills |
| "Measure the performance of my database queries" | Contains "measure" + "performance" | No -- database perf, not skill perf |

These are exactly the "near-miss" queries the description guide says are most valuable for testing. The current description has no defense against any of them.

### 1.4 Pushiness Assessment

The description guide notes that Claude tends to **undertrigger** and recommends being "slightly pushy." The current description is moderately pushy in its enumeration ("Use when users want to create a skill from scratch, update or optimize an existing skill, run evals..."). However, the pushiness is expressed through *listing more capabilities* rather than through *broadening the trigger context*.

Better pushiness: "Use when doing anything related to creating, testing, iterating on, or debugging Claude Agent Skills -- even if the user doesn't explicitly mention 'skills' but is describing a workflow they want to capture or automate."

That approach is pushy in a way that expands the semantic aperture without adding false-positive risk (because the NOT clause would handle the boundaries).

---

## 2. Frontmatter Analysis

### Current Frontmatter

```yaml
---
name: skill-creator
description: Create new skills, modify and improve existing skills, and measure skill performance. Use when users want to create a skill from scratch, update or optimize an existing skill, run evals to test a skill, benchmark skill performance with variance analysis, or optimize a skill's description for better triggering accuracy.
---
```

### 2.1 Required Fields

| Field | Present | Valid | Notes |
|-------|---------|-------|-------|
| `name` | Yes | Yes | "skill-creator" -- lowercase-hyphenated, 13 chars, no reserved words. Clean. |
| `description` | Yes | Partially | Present and under 1024 chars, but missing NOT clause (see above). |

### 2.2 Missing Optional Fields That Would Add Value

| Field | Why it matters | Suggested value |
|-------|---------------|-----------------|
| `allowed-tools` | Least privilege. This skill spawns subagents, reads/writes files, runs Python scripts, opens browsers. Without `allowed-tools`, it implicitly has access to everything. | `Read,Write,Edit,Bash,Glob,Grep` |
| `argument-hint` | The skill supports multiple entry points: create from scratch, improve existing, run evals. An argument hint would improve discoverability via autocomplete. | `'[skill-path] [action: create\|improve\|eval\|optimize-description]'` |
| `metadata.category` | Useful for gallery/dashboard tooling. This is clearly a meta/productivity skill. | `Productivity & Meta` |
| `metadata.tags` | Would help external tooling discover and categorize. | `[create-skill, improve-skill, eval, benchmark, skill-testing]` |
| `metadata.pairs-with` | The skill body references agents (grader, comparator, analyzer) and the description optimization loop. Declaring relationships would help orchestration. | `[{skill: skill-architect, reason: "Architect designs structure; creator implements and tests"}, {skill: skill-grader, reason: "Grading subagent used during eval loop"}]` |

### 2.3 Name-Description Alignment

The name "skill-creator" and the description's opening "Create new skills, modify and improve existing skills, and measure skill performance" are **reasonably aligned** but imperfect. The name says "creator" (implies *making new things*), but the description covers creating, modifying, improving, measuring, benchmarking, and optimizing descriptions. That is closer to "skill-lifecycle-manager" than "skill-creator."

This is the "Misaligned Name and Description" pattern from the description guide (Example 6). It's not as severe as the database/marketing example, but it does create a mild semantic mismatch: the name suggests creation, the description says "also improving, testing, benchmarking, and optimizing." A user who wants to *test* their skill might not think to invoke something called "skill-creator."

**Recommendation**: Either narrow the description to match the name (creation-focused) or accept the broad scope and note that the name is a known shorthand.

---

## 3. Comparison with skill-architect's Description

For reference, skill-architect's description:

```yaml
description: Design, create, audit, and improve Claude Agent Skills with expert-level progressive disclosure. Use when building new skills, reviewing existing skills, debugging activation failures, encoding domain expertise, designing skills for subagent consumption, or understanding platform constraints and distribution surfaces. NOT for general Claude Code features, runtime debugging, non-skill coding, or MCP server implementation.
```

| Criterion | skill-architect | skill-creator | Winner |
|-----------|----------------|---------------|--------|
| NOT clause | Yes (4 exclusions) | No | skill-architect |
| Semantic coherence | "Design, create, audit, and improve" -- one verb phrase | Three separate sentences listing seven capabilities | skill-architect |
| Domain qualifier | "Claude Agent Skills" -- specific | "skills" -- ambiguous (could be any kind of skill) | skill-architect |
| Pushiness | Moderate (lists 6 trigger situations) | Moderate (lists 5 trigger situations) | Tie |
| Length | ~53 words | ~48 words | Both in ideal range |
| Specificity | "progressive disclosure", "activation failures", "subagent consumption", "platform constraints" | "variance analysis", "triggering accuracy" | skill-architect (more user-intent-aligned) |

This comparison reveals a **collision risk**: both skills trigger on "create a skill", "improve a skill", and "debug activation." Without a NOT clause on skill-creator (and without explicit differentiation), the runtime must choose between them based on semantic similarity alone. Adding a NOT clause to skill-creator would help disambiguate: "NOT for skill architecture design, progressive disclosure planning, or platform constraint analysis" would cleanly partition the two.

---

## 4. Specific Findings

### Finding 1: Missing NOT Clause (Critical)

**Severity**: High
**Impact**: False positives on performance benchmarking, general testing, writing optimization, and personal skill improvement queries.

**Recommended fix**: Append a NOT clause:
```
NOT for general coding advice, non-skill performance benchmarking, unit test writing, skill architecture design, or platform constraint documentation.
```

### Finding 2: Enumerated List Instead of Semantic Signal (Moderate)

**Severity**: Medium
**Impact**: The "Use when" clause reads like a feature list rather than a semantic aperture. It is effective but suboptimal -- it trades activation breadth for specificity in a way that may miss rephrased queries.

**Recommended fix**: Replace the enumerated list with a broader semantic signal:
```
Use when building, testing, iterating on, or optimizing any Claude Agent Skill -- including drafting new skills from scratch, improving existing ones with eval-driven feedback loops, running benchmarks, or optimizing descriptions for better triggering.
```

### Finding 3: "skills" vs "Claude Agent Skills" (Moderate)

**Severity**: Medium
**Impact**: The bare word "skills" in the description is ambiguous. "Improve my writing skills" would match. "Claude Agent Skills" or "SKILL.md files" would be unambiguous.

**Recommended fix**: Qualify every instance of "skills" with "Claude Agent Skills" or "SKILL.md-based skills."

### Finding 4: Missing `allowed-tools` (Low-Medium)

**Severity**: Low-Medium
**Impact**: The skill runs Python scripts, spawns subagents via `claude -p`, opens browsers, writes files. Without `allowed-tools`, it implicitly has unrestricted access. This violates least-privilege principles, though for a meta-skill this is less dangerous than for a domain skill.

**Recommended fix**: Add `allowed-tools: Read,Write,Edit,Bash,Glob,Grep`

### Finding 5: Missing `argument-hint` (Low)

**Severity**: Low
**Impact**: Users must read the SKILL.md body to understand what arguments to pass. An argument hint would improve the autocomplete/slash-command experience.

**Recommended fix**: Add `argument-hint: '[skill-path] [action: create|improve|eval|describe]'`

### Finding 6: Name-Description Scope Mismatch (Low)

**Severity**: Low
**Impact**: "creator" implies making new things; the description covers the full lifecycle (create, improve, test, benchmark, optimize). Mild semantic confusion for users deciding between this and skill-architect.

**Recommended fix**: Either rename to `skill-builder` or `skill-lifecycle` (breaking change, likely not worth it) or add a note in the SKILL.md body explaining the name is shorthand for the full creation lifecycle.

---

## 5. Recommended Rewritten Description

Applying the `[What] [When to use] NOT [Exclusions]` formula:

```yaml
description: >-
  Create, test, and iteratively improve Claude Agent Skills through eval-driven
  feedback loops, quantitative benchmarking, and description optimization. Use
  when building a new skill from scratch, improving an existing skill based on
  test results, running eval suites to measure skill quality, or optimizing a
  skill's description for better activation accuracy. NOT for skill architecture
  design or progressive disclosure planning (use skill-architect), general
  coding advice, non-skill performance benchmarking, or unit test writing.
```

**Changes from current**:
1. Added "Claude Agent Skills" qualifier (Finding 3)
2. Added "eval-driven feedback loops" and "quantitative benchmarking" as semantic signals for the skill's actual strength
3. Added NOT clause with 4 exclusions (Finding 1)
4. Explicitly defers to skill-architect for architecture concerns (resolves collision)
5. Replaced flat enumeration with a more coherent semantic statement (Finding 2)
6. ~75 words / ~490 characters -- within all limits

---

## 6. Scoring Breakdown (Description & Frontmatter Only)

| Criterion | Score | Rationale |
|-----------|-------|-----------|
| Formula compliance | 4/10 | Has What and When, but completely missing NOT clause -- the most critical piece for preventing false positives. |
| Semantic activation quality | 5/10 | Good domain terms but expressed as a feature list rather than coherent semantic signal. Ambiguous "skills" without qualifier. |
| Anti-query defense | 2/10 | Zero defense against near-miss queries. At least 5 plausible false-positive scenarios identified. |
| Synonym coverage | 5/10 | Good for creation verbs, misses troubleshooting and conversion phrasings the skill body supports. |
| Name-description alignment | 7/10 | Reasonably aligned but name ("creator") understates the scope the description claims. |
| Frontmatter completeness | 4/10 | Only required fields present. Missing allowed-tools, argument-hint, metadata. Defensible for a first-party skill but leaves value on the table. |
| Pushiness calibration | 6/10 | Moderately pushy through enumeration, but pushiness is expressed as *more items* rather than *broader aperture*. |
| Collision avoidance | 3/10 | Significant overlap with skill-architect on "create", "improve", "debug activation" with no disambiguation mechanism. |

**Composite (Description & Frontmatter)**: **5/10** (Grade: C -- Functional but needs work)

---

## 7. Summary

The skill-creator's description is a working but unrefined activation signal. Its most critical deficiency is the **complete absence of a NOT clause**, which is the primary mechanism for preventing false positives and disambiguating from adjacent skills (particularly skill-architect). The description reads as a flat feature list rather than a coherent semantic statement, and the bare word "skills" creates ambiguity with non-Claude-skill contexts.

The frontmatter is minimal -- only `name` and `description`. While the required fields are present and valid, the absence of `allowed-tools` means the skill runs with unrestricted tool access, and the missing `argument-hint` reduces discoverability.

The recommended rewrite (Section 5) addresses all six findings while staying within platform constraints. The most impactful single change would be adding a NOT clause -- even a brief one would move the score from 5/10 to approximately 7/10.
