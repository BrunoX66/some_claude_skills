# Architectural Evaluation: skill-creator

**Score: 8.2 / 10 (Grade: B+)**

**Evaluator**: skill-architect (progressive disclosure architecture + 7-type extension taxonomy)
**Target**: skill-creator (Anthropic official, via `claude-plugins-official`)
**Date**: 2026-03-06
**SKILL.md line count**: 479

---

## Scoring Breakdown

| Category | Score | Notes |
|----------|-------|-------|
| Activation Precision | 8/10 | Strong description, but no NOT clause |
| Domain Expertise Depth | 9/10 | Deep, experience-earned knowledge about iterative skill improvement |
| Progressive Disclosure | 7/10 | Good layer 2/3 split, but layer 2 at the 500-line ceiling |
| Self-Containment | 9/10 | 2,373 lines of working Python tooling, HTML viewers, packaging |
| Maintainability | 8/10 | Well-organized scripts, clear schemas, but no CHANGELOG or versioning |

**Composite**: (8 + 9 + 7 + 9 + 8) / 5 = **8.2**

---

## 1. Three-Layer Progressive Disclosure Analysis

### Layer 1: Metadata (Frontmatter)

```yaml
name: skill-creator
description: Create new skills, modify and improve existing skills, and
  measure skill performance. Use when users want to create a skill from
  scratch, update or optimize an existing skill, run evals to test a skill,
  benchmark skill performance with variance analysis, or optimize a skill's
  description for better triggering accuracy.
```

**Strengths:**
- The description is long, specific, and covers the full functional surface area. It names five distinct use cases explicitly, which combats Claude's undertriggering tendency.
- The name is clean kebab-case and self-evident.

**Weaknesses:**
- **No NOT clause.** This is a notable omission for a skill of this sophistication. The description tells Claude when to trigger but never tells it when NOT to. Given that skill-creator competes for activation with adjacent concepts -- "help me write better code," "review this," "test this feature" -- explicit exclusions would sharpen activation precision. The skill-architect's description formula calls for `[What] [When to use]. NOT for [Exclusions]`.
- **No `allowed-tools` field.** The skill relies heavily on Bash (spawning subagents via `claude -p`, running Python scripts), Read, Write, Edit, and presumably Glob/Grep for finding workspace files. Declaring these would follow least-privilege principles and make the skill's operational requirements self-documenting.
- **No `argument-hint`.** A hint like `"[skill-path] [action: create|improve|benchmark|optimize-description]"` would improve the slash-command UX and signal expected usage patterns.
- **No custom metadata.** Fields like `category`, `tags`, `pairs-with` would aid catalog organization and inter-skill composition, though these are optional.

**Score rationale (8/10)**: The description's coverage of trigger scenarios is strong. The missing NOT clause is the main gap -- for a meta-skill that's likely to be present alongside many other skills in a user's catalog, false activation risk from adjacent queries ("test my code," "benchmark this API") is real.

### Layer 2: SKILL.md Body

At 479 lines, the SKILL.md sits right at the 500-line ceiling. This is borderline -- it works, but has essentially no headroom for growth.

**Structural analysis:**

The body is organized into these sections:
1. High-level overview of the create-iterate loop (lines 6-31)
2. Communication guidance for mixed-expertise users (lines 32-43)
3. Creating a skill: Capture Intent, Interview, Write SKILL.md (lines 45-161)
4. Running and evaluating test cases -- the core eval loop (lines 163-289)
5. Improving the skill -- iteration philosophy (lines 292-323)
6. Advanced: Blind comparison (lines 325-330)
7. Description Optimization -- trigger eval workflow (lines 332-404)
8. Package and Present (lines 408-417)
9. Claude.ai-specific adaptations (lines 420-437)
10. Cowork-specific adaptations (lines 440-449)
11. Reference file index (lines 452-464)
12. Repeated emphasis of core loop (lines 466-479)

**Strengths:**
- The high-level overview at the top is excellent. It gives the agent a conceptual model ("figure out where the user is in this process and then jump in") before drowning it in procedure. This is good progressive disclosure within layer 2.
- The "Communicating with the user" section is unusually thoughtful. It acknowledges the new-user population with genuine empathy, and the calibration examples ("JSON" vs. "evaluation") are practical.
- The "Improving the skill" section is where the real expertise lives. Principles like "generalize from feedback," "keep the prompt lean," "explain the why," and "look for repeated work" are genuine shibboleths -- the kind of advice that separates someone who has actually iterated on dozens of skills from someone who has read a tutorial.
- The platform-specific sections (Claude.ai, Cowork) show maturity. Rather than pretending one workflow fits all surfaces, the skill explicitly adapts. This is a pattern that many skills neglect.

**Weaknesses:**
- **No Mermaid diagrams.** The skill describes a multi-phase iterative process with branching paths (create vs. improve, subagent vs. inline, browser vs. headless), but renders all of this as prose. A flowchart of the core loop -- or a state diagram showing the lifecycle stages (draft, eval, iterate, optimize-description, package) -- would make the process structure instantly parseable by both agents and humans. This is a notable miss for a skill of this complexity.
- **Dense procedural blocks.** Steps 1-5 of the eval workflow are written as a continuous sequence with subsections. While the instruction "don't stop partway through" justifies the monolithic structure, the agent still needs to parse dense prose to extract the procedure. Numbered lists are used inconsistently -- sometimes with clear step headers, sometimes buried in paragraphs.
- **Repeated instructions.** The core loop is stated three times: once in the overview (lines 10-19), once implicitly through the detailed sections, and once explicitly at the end (lines 466-477). The final repetition ("Repeating one more time the core loop here for emphasis") is honest about being redundant. Whether this helps or hurts depends on how Claude handles repeated instructions, but from a structural standpoint it adds ~15 lines to an already ceiling-scraping file.
- **The "Cool? Cool." line (line 30).** Stylistically charming, but it's a non-functional token in a space-constrained document. A minor quibble.

### Layer 3: References and Bundled Resources

The skill has a rich layer 3:

**Reference files:**
- `references/schemas.md` -- JSON schemas for evals.json, grading.json, benchmark.json, etc.

**Agent definitions:**
- `agents/grader.md` -- Grader subagent instructions (224 lines, detailed)
- `agents/comparator.md` -- Blind A/B comparison agent (203 lines)
- `agents/analyzer.md` -- Post-hoc analysis + benchmark analysis (275 lines)

**Scripts (2,373 lines total):**
- `scripts/run_loop.py` (332 lines) -- Full eval+improve optimization loop with train/test split
- `scripts/run_eval.py` (310 lines) -- Individual evaluation runner
- `scripts/aggregate_benchmark.py` (401 lines) -- Benchmark aggregation
- `scripts/improve_description.py` (248 lines) -- LLM-powered description improvement
- `scripts/generate_report.py` (326 lines) -- HTML report generation
- `scripts/package_skill.py` (136 lines) -- .skill file packager
- `scripts/quick_validate.py` (102 lines) -- YAML frontmatter validation
- `scripts/utils.py` (47 lines) -- Shared utilities

**Eval viewer:**
- `eval-viewer/generate_review.py` (471 lines) -- Self-contained HTTP server + HTML generator
- `eval-viewer/viewer.html` -- Viewer template

**Assets:**
- `assets/eval_review.html` -- Eval review HTML template for description optimization

**Strengths:**
- The layer 3 depth is exceptional. This is one of the most thoroughly tooled skills I've encountered. The scripts are not stubs -- they are production-quality Python with proper argument parsing, error handling, parallelism, and structured output.
- The agent definitions are well-separated by concern (grading vs. comparing vs. analyzing). Each has clear input/output contracts with JSON schemas.
- The `run_loop.py` implements a sophisticated train/test split to prevent overfitting during description optimization. This is genuine ML-engineering discipline applied to skill development.
- The eval viewer is self-contained (stdlib-only Python HTTP server), which means zero setup for users.

**Weaknesses:**
- The SKILL.md's reference index (lines 452-464) is minimal. It lists files but doesn't provide the 1-line "consult when..." guidance that skill-architect recommends. The agent encountering this skill for the first time must infer when to read `agents/analyzer.md` vs. `agents/comparator.md` from the section text rather than from a clear index.
- The `quick_validate.py` has a hardcoded `ALLOWED_PROPERTIES` set that is already stale. It allows only `{name, description, license, allowed-tools, metadata, compatibility}` but the current Claude Code spec supports additional fields like `argument-hint`, `disable-model-invocation`, `user-invocable`, `context`, `agent`, `model`, `hooks`, `dependencies`, `bundled-resources`, `distribution`. Skills using these newer fields would fail validation. This is a temporal knowledge gap that the skill-architect rubric specifically warns about.

---

## 2. Extension Taxonomy Awareness

### Does skill-creator understand the 7-type taxonomy?

**Partially.** The skill demonstrates strong practical understanding of skills-as-extension-type but does not explicitly engage with the broader taxonomy.

**Evidence of understanding:**

- **Skills as passive knowledge**: The "Skill Writing Guide" section (lines 72-139) clearly understands that skills are markdown-based knowledge injection. The progressive disclosure explanation (lines 86-109) matches the taxonomy's three-layer model almost exactly.
- **Scripts as workhorse tools**: The skill bundles 8 scripts and treats them as first-class operational components, not afterthoughts. This aligns with the taxonomy's "Skills + Scripts = immediately productive" principle.
- **Subagents (agents/)**: The three agent definitions (grader, comparator, analyzer) follow proper subagent design -- 4-section prompts (role, inputs, process, output format), clear scope boundaries, JSON output contracts. This is well-done.

**Evidence of gaps:**

- **No mention of Plugins**: The skill packages its output as `.skill` files but doesn't discuss when a skill should graduate to a plugin. For a meta-skill about skill creation, this is a significant architectural omission. The user who creates a great skill with skill-creator may want to distribute it, but the skill doesn't guide them toward the plugin packaging path.
- **No mention of MCPs**: The SKILL.md mentions "Check available MCPs" in the Interview step but doesn't explain the skill-MCP boundary. Given that the skill teaches people to create skills, some users will inevitably try to create skills that should be MCPs (external API wrappers, auth-requiring tools). The taxonomy's "Common Mistakes: MCP for Everything" and "Script That Should Be an MCP" anti-patterns are relevant here but absent.
- **No mention of Hooks**: The skill doesn't discuss how hooks interact with skills (scoped hooks, lifecycle events). This is less critical but represents a gap in the architectural picture.
- **No mention of Agent SDK**: No discussion of how skills created by skill-creator would work in SDK-powered agents (where `setting_sources=["project"]` loads skills). This matters for enterprise users.

**Verdict**: The skill is an excellent practitioner of the skills-scripts-subagents trio but doesn't teach the full taxonomy. For its primary purpose (creating skills), this is acceptable. But as the official Anthropic skill-creation tool, users will come to it with edge cases that cross taxonomy boundaries, and it currently offers no guardrails for those cases.

---

## 3. Platform Constraints Handling

### Cross-surface awareness

**Strong.** The skill explicitly addresses three deployment surfaces:
- **Claude Code**: Primary workflow with full subagent support
- **Claude.ai**: Adapted workflow without subagents, no browser, inline review
- **Cowork**: Adapted for headless environments, static HTML output

This is better than most skills, which assume a single environment. The adaptations are substantive, not token acknowledgments.

### Constraint adherence

| Constraint | Status | Notes |
|------------|--------|-------|
| Name length (64 chars) | PASS | "skill-creator" = 13 chars |
| Name format (kebab-case) | PASS | Lowercase, hyphens only |
| Reserved words | PASS | No "anthropic" or "claude" |
| Description length (1024 chars) | PASS | ~350 chars, well under limit |
| Total upload size (8MB) | UNKNOWN | Not checked, but scripts + HTML could approach this |
| Skills per API request (8) | N/A | Meta-skill, not typically used via API |
| XML tags in name/desc | PASS | None present |

### Validation gap

The `quick_validate.py` script validates constraints but is incomplete. It correctly checks name format, name length, description length, and angle brackets, but its `ALLOWED_PROPERTIES` whitelist is outdated (missing 9 valid frontmatter fields). This means skill-creator could reject valid skills or give users false confidence about invalid ones.

---

## 4. Writing Quality and Expertise Depth

### Shibboleths and Anti-Patterns

The skill contains genuinely expert-level knowledge that cannot be acquired from surface reading:

1. **"Generalize from the feedback"** (line 298): The insight that eval iteration risks overfitting to test cases is the single most important meta-lesson of skill development. The skill names it explicitly and warns against "fiddly overfitty changes" and "oppressively constrictive MUSTs."

2. **"Explain the why"** (line 302): The instruction to reframe rigid ALWAYS/NEVER directives as reasoned explanations reflects deep experience with LLM prompt engineering. "Today's LLMs are *smart*" is a shibboleth -- it signals that the author understands that Claude responds better to justified instructions than to imperative commands.

3. **"Look for repeated work"** (line 304): The pattern of detecting when multiple test runs independently write the same helper script, then bundling that script into the skill, is exactly the kind of practical optimization that only emerges from iterating on many skills.

4. **"Pushy descriptions"** (line 67): The counter-intuitive advice to make descriptions "a little bit pushy" reflects real measurement of Claude's undertriggering tendency.

5. **Train/test split for description optimization** (in `run_loop.py`): The implementation of holdout validation to prevent description overfitting is sophisticated and draws from ML methodology.

### Missing anti-patterns

- No explicit shibboleth about the difference between a skill that teaches a process vs. a skill that encodes domain knowledge. These are architecturally different and the skill treats them as one thing.
- No warning about the "documentation dump" anti-pattern -- putting an entire API reference into SKILL.md instead of distilling decision trees.
- No guidance on when a skill has become too broad and should be split.

---

## 5. Process Architecture

### The Core Loop

The skill defines a clear iterative process: Draft -> Test -> Review -> Improve -> Repeat. This is fundamentally sound and well-structured.

**Strength: Parallel execution design.** The instruction to spawn with-skill and baseline runs simultaneously (Step 1) is operationally efficient and prevents the sequential anti-pattern where baselines are run as an afterthought.

**Strength: Human-in-the-loop at every iteration.** The eval viewer ensures the user reviews qualitative outputs before the skill proceeds to make changes. This prevents the agent from optimizing in a direction the user doesn't want.

**Weakness: No explicit stopping criteria.** The skill says "keep going until the user is happy, feedback is empty, or you're not making progress," but provides no quantitative threshold. How many iterations is too many? When does diminishing returns set in? The benchmarking infrastructure is there, but the decision logic for when to stop is entirely qualitative.

**Weakness: No cost estimation.** The skill spawns multiple subagents per iteration (with-skill runs, baseline runs, grader, analyzer). Each subagent is a full Claude invocation. For a 3-eval, 3-iteration run, that's potentially 18+ Claude calls. The skill never estimates or communicates this cost to the user.

---

## 6. Comparison with skill-architect Standards

| Criterion | skill-architect Expectation | skill-creator Status | Delta |
|-----------|---------------------------|---------------------|-------|
| Description formula | `[What] [When] NOT [Exclusions]` | `[What] [When]` only | Missing NOT clause |
| SKILL.md line count | <500 (ideal <300) | 479 (at ceiling) | Needs trimming |
| Mermaid diagrams | Use for any process/decision tree | None | Major gap |
| Shibboleth template | Novice/Expert/Timeline/LLM mistake | Ad hoc expertise, no template | Style difference |
| Reference index | 1-line "consult when..." per file | Bare file list | Weak index |
| CHANGELOG | Required | Missing | Gap |
| Validation scripts | Must actually work | `quick_validate.py` has stale allowlist | Partial |
| allowed-tools | Declared in frontmatter | Missing | Gap |
| Visual artifacts | Diagrams for all processes | None | Gap |

---

## 7. Specific Recommendations

### High Priority

1. **Add NOT clause to description.** Append: `NOT for general coding advice, non-skill code review, MCP server development, or runtime debugging.`

2. **Add at least one Mermaid diagram.** The core create-iterate loop is the obvious candidate. A flowchart showing the branching paths (create vs. improve, with-subagents vs. inline, browser vs. headless) would reduce cognitive load significantly.

3. **Fix `quick_validate.py` allowlist.** Add `argument-hint`, `disable-model-invocation`, `user-invocable`, `context`, `agent`, `model`, `hooks`, `dependencies`, `bundled-resources`, `distribution` to `ALLOWED_PROPERTIES`.

4. **Add `allowed-tools` to frontmatter.** At minimum: `Read,Write,Edit,Bash,Glob,Grep`.

### Medium Priority

5. **Trim SKILL.md by 50-80 lines.** Move the Claude.ai and Cowork adaptations to `references/platform-adaptations.md`. These are environment-specific details that only matter in those contexts. This would bring SKILL.md under 400 lines with room to grow.

6. **Improve reference file index.** Change the bare list to a table with "consult when" guidance:
   ```
   | File | Consult When |
   | agents/grader.md | Spawning grader subagents for eval runs |
   | agents/comparator.md | Setting up blind A/B comparison |
   ```

7. **Add taxonomy boundary guidance.** A brief section (5-10 lines) warning users that if their intended skill requires API authentication, stateful connections, or lifecycle automation, they may need an MCP, hook, or plugin instead.

### Low Priority

8. **Add CHANGELOG.md.** Track version history for this skill.

9. **Add `argument-hint`.** Something like: `"[skill-path] [action: create|improve|benchmark|describe]"`

10. **Consider `pairs-with` metadata.** This skill pairs naturally with skill-grader and skill-architect -- declaring this in frontmatter aids catalog tooling.

---

## 8. Summary

skill-creator is an exceptionally well-built skill with genuine depth. Its tooling layer (2,373 lines of production Python) is among the best I've seen -- the eval viewer, benchmark aggregation, description optimization loop with train/test split, and packaging pipeline form a complete skill development IDE. The writing reflects real expertise earned through iteration, not surface-level tutorial knowledge.

The architectural gaps are mostly cosmetic relative to its core mission: missing NOT clause, no Mermaid diagrams, a stale validation allowlist, and a SKILL.md that's at the ceiling without headroom. These are all fixable in a single iteration.

The deeper gap is in taxonomy awareness. As Anthropic's official skill-creation tool, skill-creator is the place where new skill authors learn what a skill IS and what it ISN'T. Currently, the skill teaches how to build great skills but doesn't teach where skills end and MCPs, hooks, plugins, or the Agent SDK begin. Users who arrive at skill-creator with a need that crosses taxonomy boundaries will get excellent skill-creation guidance for a problem that may not be a skill-shaped problem.

That said: for what it sets out to do -- create, test, iterate, benchmark, and optimize skills -- it does it at a level that most skills don't reach. The score of 8.2 reflects a skill that is clearly production-ready with room for targeted improvements.
