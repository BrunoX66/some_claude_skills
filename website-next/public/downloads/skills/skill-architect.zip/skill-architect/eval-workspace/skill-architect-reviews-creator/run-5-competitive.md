# Competitive Analysis: skill-architect vs skill-creator (Anthropic Official)

**Evaluator**: skill-architect methodology
**Date**: 2026-03-06
**Evaluation type**: Competitive head-to-head
**Run**: 5

---

## Comparison Table

| Dimension | skill-architect | skill-creator (Anthropic) | Winner |
|-----------|----------------|---------------------------|--------|
| **Eval Infrastructure** | Validation scripts only (`validate_skill.py`, `validate_mermaid.py`, `check_self_contained.py`). No runtime eval loop. No subagent-based test harness. | Full eval pipeline: `run_eval.py`, `run_loop.py`, `aggregate_benchmark.py`, `generate_review.py`, grader/comparator/analyzer agents, HTML viewer with feedback capture, train/test split, variance analysis, blind comparison. | **skill-creator** (by a wide margin) |
| **Description Optimization** | Manual formula: `[What][When][NOT]`. Checklist-based testing (5 should-trigger, 5 shouldn't). Detailed guide in `references/description-guide.md` with 7 bad-to-good patterns. | Automated optimization loop: generates 20 eval queries, runs `claude -p` to test actual triggering, train/test split to prevent overfitting, iterates up to 5 times with extended thinking, opens live HTML report, selects best by held-out test score. | **skill-creator** (empirical > theoretical) |
| **Progressive Disclosure Depth** | Deep. Three-layer architecture explicitly defined (metadata/SKILL.md/references). Token budgets specified. 13 reference files with clear "consult when" index. Lazy-loading rules codified. | Acknowledged. Three-level system described (metadata/body/bundled resources). Approximate word counts given ("~100 words", "<500 lines ideal"). Domain organization pattern shown. Less prescriptive about loading mechanics. | **skill-architect** |
| **Platform Awareness** | Comprehensive. Covers all 4 distribution surfaces (Claude Code, API, claude.ai, Agent SDK). Documents 7 extension types with graduation path. Includes platform constraints (8MB upload, 8 skills/request, no cross-surface sync). Beta headers documented. Plugin marketplace architecture. | Mentions Claude Code primarily. Brief Claude.ai section noting no subagents and no browser. Mentions Cowork constraints. No API surface coverage. No plugin architecture. No mention of platform limits. | **skill-architect** (much more complete) |
| **Anti-Pattern Coverage** | 10 named anti-patterns in SKILL.md, 4 detailed case studies in references. Shibboleth template with Novice/Expert/Timeline/LLM-mistake/Detection structure. Cross-domain examples (CLIP, React, Redux, Next.js). Temporal knowledge patterns explicitly tracked. | Implicit rather than cataloged. "Generalize from feedback" and "don't overfit" are anti-patterns-by-implication. "Principle of Lack of Surprise" is a security anti-pattern. The improvement guidance warns against "fiddly overfitty changes" and "oppressively constrictive MUSTs". No formal anti-pattern taxonomy. | **skill-architect** |
| **Writing Quality** | Technical, systematic, dense. Uses tables, checklists, Mermaid diagrams. Imperative tone ("Write in imperative form"). Occasionally reads like a spec document. The density is earned -- every line carries information -- but it demands focus. | Conversational, warm, self-aware. "Cool? Cool." and "Sorry in advance but I'm gonna go all caps here." The tone invites rather than instructs. Explains WHY with genuine empathy for the model reading it. The paragraph on generalization vs. overfitting (Section: Improving the skill, point 1) is among the finest paragraphs of meta-instruction I have read. | **skill-creator** (more humane, more effective) |
| **Subagent Design** | Dedicated section in SKILL.md + full reference file. Three loading layers. Four-section prompt structure. Orchestration patterns (single-specialist, chain, parallel). Input/output contracts. Anti-patterns for subagent skill design. | Agents used as infrastructure (grader, comparator, analyzer) but no guidance on designing skills FOR subagent consumption. The skill's own subagent usage is exemplary, but it does not teach the skill author how to do this. | **skill-architect** |
| **Visual Documentation** | Mermaid is a first-class citizen. 23 diagram types cataloged. Full reference with examples of every type. Best practices for agent parseability. Validation script for syntax checking. | No Mermaid diagrams in SKILL.md. No visual artifacts guidance. The skill is entirely prose-based. This is notable because it is a well-structured skill despite the absence -- the prose is clear enough to not need diagrams. | **skill-architect** |
| **Knowledge Engineering** | Dedicated reference file. Five KE methods (Protocol Analysis, Repertory Grid, Card Sorting, Critical Incident, Concept Mapping). Expert cognition architecture (Dreyfus, Klein). AI-native techniques (Corpus Distillation, Interview Simulation, Cross-Source Triangulation). Book recommendations for extracting expert thinking. | Not addressed. The skill assumes the user already knows what they want. Interview phase exists ("Proactively ask questions about edge cases") but no structured knowledge acquisition methodology. | **skill-architect** |
| **Iteration Loop** | Six-step creation process. Validation scripts for automated checking. "Iterate after real-world use" is the guidance -- no automated iteration infrastructure. | Fully operationalized iteration loop. Spawn runs (with-skill AND baseline) in parallel. Draft assertions while runs execute. Grade with structured agent. Aggregate into benchmark with variance analysis. Launch HTML viewer for human review. Read feedback JSON. Improve skill. Repeat. This is a working feedback loop, not just a concept. | **skill-creator** (dramatically) |
| **Frontmatter Documentation** | Exhaustive. Required vs. optional fields in separate tables. Invalid keys explicitly called out with corrections. Custom keys explained. Common rejection causes with symptoms and fixes. | Minimal but sufficient. name, description, compatibility mentioned. "The rest of the skill :)" as documentation for the body. Relies on the user knowing the format or discovering it. | **skill-architect** |
| **Audience Awareness** | Assumes technical competence. Written for someone building Claude extensions professionally. Does not modulate tone based on user signals. | Explicitly addresses audience range. "There's a trend now where the power of Claude is inspiring plumbers to open up their terminals." Guidelines for when to explain "JSON" vs. when it is safe to use without definition. | **skill-creator** |
| **Tool Self-Containment** | `validate_mermaid.py` (649 lines, production-quality). References `validate_skill.py` and `check_self_contained.py` but these are phantom references -- the scripts do not exist in the skill directory. | 9 working scripts: `run_eval.py`, `run_loop.py`, `improve_description.py`, `aggregate_benchmark.py`, `generate_report.py`, `package_skill.py`, `quick_validate.py`, `utils.py`. Plus `generate_review.py` with HTML viewer. Plus `eval_review.html` asset. All real, all functional. | **skill-creator** (substantially) |
| **Scope / Ambition** | Encyclopedic. Covers skill creation, auditing, improvement, platform taxonomy, extension types, subagent design, knowledge engineering, visual artifacts, plugin distribution, skill composition, lifecycle management. Tries to be the single authoritative reference for everything skill-related. | Focused. Does one thing -- the create/test/improve loop -- and does it with operational depth. Scope is deliberately narrow: "figure out where the user is in this process and then jump in and help them progress." | **Contextual** (see below) |

---

## Detailed Analysis

### Where skill-creator wins decisively

**1. The eval loop is real infrastructure, not theory.**

Skill-creator ships a complete evaluation pipeline. The `run_loop.py` script alone is 333 lines of working Python that:
- Splits eval sets into train/test (stratified by should_trigger)
- Runs queries against `claude -p` with the skill loaded
- Tracks precision, recall, and accuracy per iteration
- Calls `improve_description.py` with extended thinking to propose improvements
- Blinds test scores from the improvement model to prevent overfitting
- Generates a live HTML report that auto-refreshes as iterations complete
- Selects the best description by held-out test score

This is not documentation. This is a working machine learning pipeline for skill descriptions. Skill-architect has nothing comparable. Its description optimization advice is a checklist ("Write 5 queries that should trigger..."). Useful, but categorically less powerful than an automated loop with train/test splits and variance tracking.

**2. The human-in-the-loop review system is sophisticated.**

The `generate_review.py` viewer presents outputs side-by-side (with-skill vs. baseline), supports iteration-over-iteration comparison, shows quantitative benchmarks alongside qualitative outputs, captures structured feedback as JSON, and supports both browser and headless (static HTML) modes. The grader agent does not just check pass/fail -- it critiques the evals themselves, flagging assertions that are "trivially satisfied" or "non-discriminating." The analyzer agent surfaces patterns hidden by aggregate statistics.

This is a mature evaluation system. It makes the assumption that skill quality is measurable and then builds the measurement infrastructure.

**3. The writing philosophy is more effective.**

Section 3 of "Improving the skill" contains this guidance:

> "Try hard to explain the **why** behind everything you're asking the model to do. Today's LLMs are *smart*. They have good theory of mind and when given a good harness can go beyond rote instructions and really make things happen... If you find yourself writing ALWAYS or NEVER in all caps, or using super rigid structures, that's a yellow flag -- if possible, reframe and explain the reasoning so that the model understands why the thing you're asking for is important."

This is correct, and it is advice that skill-architect partially violates. Skill-architect uses imperative form, validation checklists, and structured anti-pattern templates. These are useful engineering artifacts, but they privilege compliance over understanding. The best skills teach WHY, not just WHAT. Skill-creator understands this at a philosophical level and encodes it as a design principle.

**4. Baseline comparison is built into the methodology.**

Every test run in skill-creator produces BOTH a with-skill output AND a baseline (no-skill or old-skill). This answers the fundamental question: "Does this skill actually help, or would Claude have done fine without it?" Skill-architect never asks this question. Its validation is structural (does the SKILL.md have the right sections?) rather than empirical (does the skill produce better outcomes?).

### Where skill-architect wins decisively

**1. Platform knowledge is comprehensive and current.**

Skill-architect documents 7 extension types (Skills, Plugins, MCP Servers, Scripts, Slash Commands, Hooks, Agent SDK) with a clear graduation path. It knows about beta headers for the API, 8MB upload limits, the Agent SDK's `setting_sources` parameter, the colon namespace syntax for plugins, 17+ hook event types, and the fact that skills don't sync across surfaces.

Skill-creator operates almost entirely within Claude Code's local development environment. It does not address how skills behave on the API, claude.ai, or in Agent SDK contexts. For someone building skills for production deployment across multiple surfaces, skill-architect is essential and skill-creator is insufficient.

**2. Progressive disclosure is a first-class architectural concept.**

Skill-architect does not just describe progressive disclosure -- it enforces it with specific rules:
- SKILL.md under 500 lines (measured)
- Reference files NOT auto-loaded (behavior-level rule)
- Each reference indexed with a 1-line "consult when" description
- "Never instruct 'read all reference files before starting'"
- Token budgets per layer (~100 tokens metadata, <5k SKILL.md, unlimited references)

Skill-creator acknowledges progressive disclosure ("~100 words", "<500 lines ideal") but does not enforce or measure it with the same precision.

**3. Knowledge engineering methodology is unique.**

The `references/knowledge-engineering.md` file is unlike anything in skill-creator. It draws on academic KE literature (Dreyfus model of skill acquisition, Klein's Recognition-Primed Decision model, Boeing's ETS system from the 1980s, Flanagan's WWII pilot studies) and translates them into actionable skill-building techniques.

The "Aha! Moment Problem" section identifies the most valuable and hardest-to-extract knowledge: conceptual phase transitions in expert thinking. The questions it prescribes ("When did [domain] stop feeling confusing and start making sense? What changed?") are the kind of questions that produce skills with genuine expertise, not just procedure checklists.

Skill-creator's interview phase is practical ("ask questions about edge cases, input/output formats, example files") but shallow by comparison.

**4. The extension taxonomy prevents architectural mistakes.**

The most common mistake a new skill author makes is choosing the wrong extension type. Should this be a skill? An MCP server? A hook? A plugin? Skill-architect's taxonomy with decision flowchart and graduation path prevents this. Skill-creator assumes you already know you want a skill.

**5. Subagent consumption patterns are production-critical.**

As multi-agent systems become more common, skills increasingly need to be designed for subagent consumption, not just direct user invocation. Skill-architect's three loading layers, output contracts, numbered steps guidance, and subagent prompt templates address a real production need that skill-creator does not acknowledge.

### Where they complement each other

The skills are not truly competitors. They operate at different points in the skill lifecycle:

1. **skill-architect** is a design-time reference. It answers: "What should a skill look like? What patterns exist? What mistakes should I avoid? How does the platform work?" It is an encyclopedia.

2. **skill-creator** is a build-time workflow. It answers: "How do I iteratively create and improve a skill, measuring progress empirically?" It is a machine.

The ideal workflow uses skill-architect for design decisions and structural guidance, then skill-creator for the create/test/improve loop. Skill-architect's `pairs-with` metadata acknowledges this: it lists skill-creator as a complement.

### Honest failures

**skill-architect's phantom tools problem.**

Skill-architect references `validate_skill.py` and `check_self_contained.py` in its SKILL.md, but these scripts do not exist in its `scripts/` directory. Only `validate_mermaid.py` exists. This is Anti-Pattern #3 (Phantom Tools) from skill-architect's own anti-pattern catalog. The skill violates its own rules. This is not a minor point. A skill about skill quality that has phantom tool references undermines its own credibility. Skill-creator, by contrast, ships 9 working scripts with no phantom references.

**skill-creator's narrow platform view.**

Skill-creator is entirely Claude Code-centric with brief nods to Claude.ai and Cowork. It does not address the API surface, the Agent SDK, plugins, hooks, or any of the broader extension ecosystem. For users deploying skills across multiple surfaces or building multi-agent systems, this is a significant gap.

**skill-architect's density problem.**

At 500 lines in SKILL.md plus 13 reference files totaling thousands of lines, skill-architect borders on information overload. The progressive disclosure architecture is sound -- reference files ARE lazy-loaded -- but the SKILL.md itself is at the upper limit of its own recommended size. Some sections (frontmatter tables, platform constraints) could be moved to references without losing core utility.

**skill-creator's silence on skill architecture.**

Skill-creator offers no guidance on:
- Mermaid diagrams or visual artifacts
- Subagent consumption patterns
- Extension type selection
- Platform constraints
- Skill composition patterns
- Knowledge engineering methodology
- Lifecycle management (versioning, deprecation)

It assumes the user knows HOW to design a skill and focuses entirely on the test/improve loop. This works for experienced skill authors but leaves beginners without structural guidance.

---

## The Verdict

**If I were building a skill from scratch today, which would I rather have guiding me?**

**Both**, used in sequence. But if forced to choose only one:

**For a first-time skill author**: skill-architect. The structural guidance, anti-pattern catalog, frontmatter documentation, platform awareness, and progressive disclosure architecture are essential for someone who does not yet know what a good skill looks like. Without this foundation, the create/test/improve loop in skill-creator is iterating on a potentially flawed structure.

**For an experienced skill author improving an existing skill**: skill-creator. Once you know the patterns, the empirical eval loop is where the value lives. The train/test split description optimizer alone is worth more than all the checklists in skill-architect for driving measurable improvement. The blind comparison system and benchmark viewer surface insights that manual review misses.

**For production deployment across surfaces**: skill-architect. Skill-creator does not know about the API, the Agent SDK, plugins, or cross-surface constraints. Skill-architect does.

**Overall edge**: skill-creator, by a narrow margin.

Here is why: skill-architect is a better reference document, but skill-creator is a better tool. In practice, tool beats reference. The eval loop in skill-creator produces measurable outcomes -- you can see whether your skill actually improves Claude's behavior. Skill-architect produces well-structured skills that LOOK correct but have no empirical validation beyond manual checklist-checking.

The gap is philosophical. Skill-architect believes quality comes from correct structure (progressive disclosure, anti-patterns, description formula, platform compliance). Skill-creator believes quality comes from empirical measurement (run it, measure it, improve it, measure again). Both are right, but empirical measurement catches problems that structural correctness misses. A skill can pass every checklist in skill-architect and still not trigger correctly or produce worse outcomes than no-skill at all. Skill-creator's baseline comparison would catch that. Skill-architect would not.

That said, skill-architect's knowledge engineering and subagent design material have no equivalent anywhere in skill-creator. The CLIP shibboleth example, the Boeing ETS case study, the expert cognition architecture from Dreyfus and Klein -- these represent genuine intellectual depth that no eval loop can substitute for. They teach you to THINK about skill design, not just iterate on it.

**Final score** (using skill-architect's own rubric):

| Category | skill-architect | skill-creator |
|----------|----------------|---------------|
| Activation Precision | 8/10 | 7/10 |
| Domain Expertise Depth | 9/10 | 7/10 |
| Progressive Disclosure | 8/10 | 6/10 |
| Self-Containment | 5/10 (phantom tools) | 9/10 |
| Maintainability | 8/10 | 7/10 |
| **Composite** | **7.6/10 (B)** | **7.2/10 (B)** |

But these scores miss the point. Add an "Empirical Validation Infrastructure" category:

| Category | skill-architect | skill-creator |
|----------|----------------|---------------|
| Eval Infrastructure | 2/10 | 10/10 |

And the composite shifts dramatically. The question is whether that category belongs in the rubric. I believe it does. Skill-architect should steal skill-creator's eval infrastructure wholesale, and skill-creator should steal skill-architect's platform knowledge, subagent design patterns, and knowledge engineering methodology. The best meta-skill is both.

---

## Recommendations

### For skill-architect (to close the gap)

1. **Build or integrate an eval loop.** The validate scripts are necessary but not sufficient. Port or wrap skill-creator's `run_eval.py` / `run_loop.py` infrastructure.
2. **Fix phantom tool references.** Ship `validate_skill.py` and `check_self_contained.py` or remove references to them. This is embarrassing for a skill that catalogs Phantom Tools as Anti-Pattern #3.
3. **Add baseline comparison methodology.** Every skill improvement should answer: "Is this better than no-skill?" Currently there is no mechanism for this.
4. **Soften the tone.** The imperative, spec-like writing style is precise but cold. Skill-creator's "explain the why" philosophy produces more effective instructions for the LLMs that consume skills.

### For skill-creator (to close the gap)

1. **Add platform awareness.** Document API-specific constraints, cross-surface behavior, plugin architecture, and Agent SDK integration.
2. **Add subagent consumption guidance.** As skills are increasingly consumed by subagents, output contracts and loading layer design become critical.
3. **Add visual artifact support.** The Mermaid diagram catalog and validation in skill-architect is genuinely useful for skill authors.
4. **Add knowledge engineering methodology.** The interview phase is too shallow. Structured KE methods produce better domain skills.
5. **Add progressive disclosure enforcement.** Current guidance is approximate ("~100 words", "<500 lines ideal"). Add specific rules and measurement.
