# General Quality Audit: Anthropic's skill-creator

**Reviewer**: skill-architect methodology
**Date**: 2026-03-06
**Target**: `/Users/erichowens/.claude/plugins/marketplaces/claude-plugins-official/plugins/skill-creator/skills/skill-creator/SKILL.md`
**SKILL.md Line Count**: 479 lines

---

## Composite Score: 7.4 / 10 (Grade: B)

A well-engineered meta-skill with sophisticated tooling, strong self-containment, and a thoughtful iterative workflow. Falls short on progressive disclosure (the SKILL.md is dense and borderline on length), lacks formal anti-patterns with shibboleth structure, and the description -- while functional -- violates its own pushy description advice. The conversational tone is a deliberate choice that trades structural rigor for accessibility, which is defensible for its audience but leaves domain expertise less extractable.

---

## Validation Checklist Results

| # | Check | Result | Notes |
|---|-------|--------|-------|
| 1 | SKILL.md exists and is <500 lines | PASS (borderline) | 479 lines -- just under the wire. One more section and it breaks the limit. |
| 2 | Frontmatter has name + description | PASS | Both present. |
| 3 | Description follows [What][When to use] NOT [Exclusions] formula | FAIL | Description lists use cases but has no NOT clause. No explicit exclusions. |
| 4 | Description is specific and context-rich | PASS (weak) | Lists 6 trigger contexts, which is good. But reads as a laundry list rather than a semantic signal. |
| 5 | Name and description are aligned | PASS | "skill-creator" and "Create new skills, modify and improve existing skills..." are aligned. |
| 6 | At least 1 anti-pattern with shibboleth template | FAIL | No anti-patterns section exists. No Novice/Expert/Timeline shibboleths. |
| 7 | All referenced files actually exist (no phantoms) | PASS | All referenced files verified: `references/schemas.md`, `agents/grader.md`, `agents/comparator.md`, `agents/analyzer.md`, `eval-viewer/generate_review.py`, `assets/eval_review.html`, all scripts in `scripts/`. |
| 8 | Scripts work (not templates), have clear CLI, handle errors | PASS | `quick_validate.py`, `aggregate_benchmark.py`, `package_skill.py`, `run_loop.py`, `run_eval.py`, `improve_description.py`, `generate_report.py` -- all are real, functional Python with argparse CLIs and error handling. |
| 9 | Reference files each have a 1-line purpose in SKILL.md | PARTIAL | References are listed in "Reference files" section at line 454 with brief descriptions. But the `assets/` directory and `eval-viewer/` are only mentioned inline in procedural steps, not indexed in a reference table. |
| 10 | Processes/decisions/lifecycles use Mermaid diagrams | FAIL | Zero Mermaid diagrams. The entire workflow is prose-only: the iteration loop, the eval pipeline, the description optimization flow. All three are multi-step processes that would benefit enormously from visual representation. |
| 11 | CHANGELOG.md tracks version history | FAIL | No CHANGELOG.md found in the skill directory. |
| 12 | If subagent-consumed: output contracts are defined | PASS | Subagent prompts are well-defined in `agents/`. JSON output schemas are specified in `references/schemas.md`. |

**Checklist Score**: 7 of 12 passed, 1 partial, 4 failed.

---

## Scoring by Category

### 1. Activation Precision: 6/10

**Description text**:
```
Create new skills, modify and improve existing skills, and measure skill performance. Use when users want to create a skill from scratch, update or optimize an existing skill, run evals to test a skill, benchmark skill performance with variance analysis, or optimize a skill's description for better triggering accuracy.
```

**Strengths**:
- Lists 6 specific trigger scenarios (create, update, optimize, run evals, benchmark, optimize description)
- Includes domain-specific terms ("evals", "benchmark", "variance analysis", "triggering accuracy")
- Name and description are well-aligned

**Weaknesses**:
- No NOT clause. This is the single most impactful omission per the skill-architect's description formula. Without exclusions, this skill will false-positive on:
  - General coding advice ("help me write better code" -- is that "improving a skill"?)
  - MCP server creation ("I want to build a tool for Claude" -- adjacent but different)
  - Prompt engineering ("make this prompt better" -- skill descriptions are prompts, but general prompts are not skills)
  - Testing workflows ("run evals" could trigger for any testing request)
- The description reads as a comma-separated list of features rather than a semantic signal that Claude can reason about
- Ironically, the skill's own body text (line 67) advises making descriptions "a little bit 'pushy'" and shows examples with NOT clauses, but the skill-creator's own description lacks both

**Recommended fix**:
```
Create new skills, modify and improve existing skills, and measure skill performance. Use when users want to create a skill from scratch, update or optimize an existing skill, run evals to test a skill, benchmark skill performance with variance analysis, or optimize a skill's description for better triggering accuracy. NOT for general coding advice, MCP server implementation, prompt engineering outside of skills, or non-skill testing workflows.
```

### 2. Domain Expertise Depth: 8/10

**Strengths**:
- The "Improving the skill" section (lines 294-307) is genuinely expert-level. The four principles (generalize from feedback, keep the prompt lean, explain the why, look for repeated work) encode real wisdom that separates novice skill authors from expert ones
- The description optimization pipeline (lines 333-404) is sophisticated -- train/test splits, overfitting prevention, multi-iteration improvement loops. This is applied ML rigor, not cargo-culted process
- The "Communicating with the user" section (lines 32-41) shows unusual awareness of audience variability -- "plumbers opening their terminals" is a real and important signal
- The blind comparison system (lines 325-329) adds genuine evaluative depth
- The test case design guidance is specific: "Not abstract requests, but requests that are concrete and specific and have a good amount of detail" (line 348)

**Weaknesses**:
- Zero formal anti-patterns. For a skill about building skills, this is a significant gap. Where are the shibboleths? What do novice skill-creators get wrong? The skill-architect identifies 10 common anti-patterns (Documentation Dump, Missing NOT clause, Phantom Tools, Template Soup, etc.) -- the skill-creator encodes none of them explicitly
- No temporal knowledge markers. When did the skill format stabilize? What changed between Claude 3 and Claude 4? What older patterns should be avoided?
- The "Writing Style" section (lines 137-139) is only 3 lines. For a meta-skill about writing skills, this is surprisingly thin. Compare to the skill-architect's emphasis on imperative form, theory of mind, and explaining the "why"

### 3. Progressive Disclosure: 6/10

**Strengths**:
- Three-layer loading is correctly used: metadata in frontmatter, core process in SKILL.md, deep dives in `agents/` and `references/`
- The SKILL.md body explicitly tells agents when to read reference files ("Read `agents/grader.md`", "See `references/schemas.md`")
- The "progressive disclosure" concept is explicitly taught in lines 86-109

**Weaknesses**:
- 479 lines is borderline. The skill-architect recommends <300 lines for SKILL.md, with 500 as the hard ceiling. This skill is 4 lines from the ceiling
- The file is front-loaded with context (lines 6-42) before getting to actionable content. The "Communicating with the user" section, while valuable, could live in a reference file
- The Claude.ai-specific instructions (lines 420-436) and Cowork-specific instructions (lines 440-449) are environment-specific adaptations that bloat the main body. These should be in `references/environment-adaptations.md` with a 1-line pointer from SKILL.md
- The "Cool? Cool." on line 30 and the all-caps "GENERATE THE EVAL VIEWER *BEFORE*" on line 446 are tonal inconsistencies that take up space better used for structural clarity
- The final "Repeating one more time" section (lines 466-478) is literally a duplication of the core loop. This is 13 lines of redundancy in a file that's already at the limit

**Estimated savings from refactoring**:
- Move "Communicating with the user" to reference: -12 lines
- Move Claude.ai instructions to reference: -16 lines
- Move Cowork instructions to reference: -12 lines
- Remove duplicated core loop summary: -13 lines
- Total: ~53 lines freed, bringing SKILL.md to ~426 lines -- much healthier

### 4. Self-Containment: 9/10

**Strengths**:
- This is where the skill-creator truly shines. The tooling is exceptional:
  - `quick_validate.py` -- validates skill frontmatter and structure
  - `aggregate_benchmark.py` -- statistical aggregation with mean/stddev/delta
  - `package_skill.py` -- creates distributable .skill files (zip format)
  - `run_loop.py` -- automated description optimization loop
  - `run_eval.py` -- evaluation runner
  - `improve_description.py` -- description improvement pipeline
  - `generate_report.py` -- report generation
  - `generate_review.py` -- HTML eval viewer with benchmark tab
  - `viewer.html` -- 1325-line full-featured review interface
  - `eval_review.html` -- trigger eval review template
- All scripts are real, working code with proper argparse CLIs, not templates
- The subagent prompts (`agents/grader.md`, `agents/comparator.md`, `agents/analyzer.md`) are complete and well-structured with clear input/output contracts
- JSON schemas are fully documented in `references/schemas.md` with field descriptions
- Zero phantom tools detected -- every referenced file exists

**Weaknesses**:
- The `quick_validate.py` has a very restrictive `ALLOWED_PROPERTIES` set that would reject valid skills using `argument-hint`, `context`, `model`, `hooks`, `user-invocable`, or `disable-model-invocation`. This is a real bug -- the validator would fail on the skill-architect's own SKILL.md (which uses `argument-hint` and `metadata`)
- No `__init__.py` module pattern for the scripts -- they use `python -m scripts.aggregate_benchmark` but the module structure assumes a specific working directory

### 5. Maintainability: 6/10

**Strengths**:
- Clear file organization: `scripts/`, `agents/`, `references/`, `assets/`, `eval-viewer/`
- JSON schemas documented in one place (`references/schemas.md`)
- Modular agent prompts that can be updated independently
- `LICENSE.txt` included

**Weaknesses**:
- No CHANGELOG.md. For a skill that explicitly teaches iteration and versioning, this is a conspicuous absence
- No version number anywhere. The skill has no `version` field in frontmatter, no semantic versioning, no way to track which version a user has
- No deprecation notices or migration guidance for changes
- The `quick_validate.py` allowed-properties list will silently reject valid properties that Anthropic adds to the skill spec in the future -- it needs a more future-proof approach

---

## Anti-Pattern Detection

Applying the skill-architect's 10 anti-pattern checklist:

| # | Anti-Pattern | Present? | Severity | Details |
|---|-------------|----------|----------|---------|
| 1 | Documentation Dump | No | -- | The skill is procedural, not a dump. Good structure. |
| 2 | Missing NOT clause | **Yes** | High | Description has no exclusions. Most impactful fix available. |
| 3 | Phantom Tools | No | -- | All references verified. |
| 4 | Template Soup | No | -- | All scripts are working code. |
| 5 | Overly Permissive Tools | N/A | -- | No `allowed-tools` in frontmatter (defaults to all). This is arguably correct for a meta-skill that needs full access, but could be explicitly declared. |
| 6 | Stale Temporal Knowledge | **Yes** | Medium | No dates on any advice. "Currently Claude has a tendency to 'undertrigger'" (line 67) -- when was this observed? Is it still true? |
| 7 | Catch-All Skill | No | -- | Appropriately scoped to skill creation/improvement. |
| 8 | Vague Description | Partial | Medium | Description is functional but lacks the formula's NOT clause. |
| 9 | Eager Loading | No | -- | Reference files are properly deferred. |
| 10 | Prose-Only Processes | **Yes** | High | Zero Mermaid diagrams for multiple complex workflows. |

**3 anti-patterns detected**: Missing NOT clause, Stale Temporal Knowledge, Prose-Only Processes.

---

## Shibboleth Analysis

The skill-creator encodes some implicit domain knowledge but never in the formal shibboleth template:

### Implicit Shibboleth 1: Overfitting in Skill Improvement
**Location**: Lines 298-299
**Content**: "Rather than put in fiddly overfitty changes, or oppressively constrictive MUSTs..."
**Analysis**: This is genuine expert knowledge -- that skill authors overfit to test cases. But it's buried in a paragraph and lacks the Novice/Expert/Timeline structure that would make it teachable.

### Implicit Shibboleth 2: Non-Discriminating Assertions
**Location**: `agents/grader.md`, lines 72-79
**Content**: The grader is taught to identify assertions that "trivially satisfied" or that "would also pass for a clearly wrong output"
**Analysis**: This is a real shibboleth -- novice eval authors write assertions that always pass. But it lives in a subagent prompt, not in the main SKILL.md where a skill author would encounter it.

### Implicit Shibboleth 3: Undertriggering vs Overtriggering
**Location**: Line 67 and line 398
**Content**: "Claude has a tendency to 'undertrigger' skills"
**Analysis**: Critical domain knowledge for description design. But no timeline, no explanation of why, no guidance on how the behavior might change.

### Missing Shibboleths (Knowledge Gaps)
The following expert knowledge is absent:
- **When to use scripts vs. prose instructions**: The skill-creator never addresses the graduation path from "tell the agent what to do" to "give the agent a script that does it"
- **The 500-line trap**: The skill-creator teaches the 500-line limit but doesn't explain why it exists (context window efficiency, attention degradation in long prompts)
- **Description keyword density**: No guidance on how many trigger terms is too many vs. too few
- **The subagent context gap**: When subagents run test cases, they lack the conversation context. This is a real pitfall that's never explicitly called out

---

## Detailed Findings

### Finding 1: The Validator Bug (High Impact)

`quick_validate.py` lines 42-49:
```python
ALLOWED_PROPERTIES = {'name', 'description', 'license', 'allowed-tools', 'metadata', 'compatibility'}
unexpected_keys = set(frontmatter.keys()) - ALLOWED_PROPERTIES
if unexpected_keys:
    return False, (
        f"Unexpected key(s) in SKILL.md frontmatter: {', '.join(sorted(unexpected_keys))}. "
        f"Allowed properties are: {', '.join(sorted(ALLOWED_PROPERTIES))}"
    )
```

This rejects skills with `argument-hint`, `context`, `model`, `hooks`, `user-invocable`, `disable-model-invocation`, `dependencies`, `distribution`, or `bundled-resources` -- all of which are valid per the Claude Code skill specification. The skill-architect's own SKILL.md would fail this validation.

This is not just a missing feature -- it's a correctness bug. Users following the skill-creator's own guidance to run `quick_validate.py` will get false rejections on valid skills.

### Finding 2: Tone as a Deliberate Choice (Informational)

The conversational tone ("Cool? Cool.", "but again, the order is flexible", "Sorry in advance but I'm gonna go all caps here") is unusual for a skill. The skill-architect methodology favors imperative form. However, this is clearly a deliberate choice for the skill-creator's unique audience: people who may be new to skill development. The informal register reduces intimidation.

The cost is structural: conversational asides consume lines in a file that's already at 479/500. The benefit is real: lower barrier to entry.

**Verdict**: Acceptable trade-off, but the conversational material should migrate to a `references/getting-started.md` if the SKILL.md needs to grow.

### Finding 3: Excellent Eval Viewer Ecosystem (Positive)

The eval viewer (`generate_review.py` + `viewer.html`) is a genuine force multiplier. It:
- Serves a local web app with qualitative output review
- Shows quantitative benchmark data with pass rates and timing
- Supports iteration comparison (`--previous-workspace`)
- Handles headless environments (`--static` mode)
- Captures structured feedback as JSON

This is exactly the kind of self-contained tooling that separates a B-grade skill from an A-grade skill. The implementation is complete, not stubbed.

### Finding 4: Missing Diagrams for Complex Workflows (High Impact)

Three workflows cry out for Mermaid diagrams:

1. **The core iteration loop** (lines 10-21): Draft -> Test -> Evaluate -> Improve -> Repeat. Currently prose-only.
2. **The eval pipeline** (lines 163-267): Spawn runs -> Draft assertions -> Capture timing -> Grade -> Aggregate -> Launch viewer. Currently an 8-step numbered list.
3. **The description optimization flow** (lines 333-404): Generate queries -> User review -> Run optimization -> Apply result. Currently prose-only.

Adding even one `flowchart LR` diagram would improve scanability and agent comprehension significantly.

### Finding 5: The "allowed-tools" Omission (Medium Impact)

The skill-creator has no `allowed-tools` in its frontmatter. This means it defaults to unrestricted tool access. For a meta-skill that spawns subagents and runs Python scripts, broad access is arguably needed. However, explicitly declaring `allowed-tools: Read,Write,Edit,Bash,Glob,Grep` would:
- Document the skill's actual needs
- Follow the least-privilege principle the skill itself teaches (line 407 of the skill-architect's SKILL.md)
- Set a better example for skill authors who read this skill as a reference

---

## Priority Improvements

Ranked by impact:

1. **Add NOT clause to description** -- Highest impact, lowest effort. Prevents false activation.
2. **Add 2-3 Mermaid diagrams** -- Transforms the prose-heavy workflow sections into scannable visual processes.
3. **Refactor environment-specific sections to references** -- Frees ~53 lines, brings SKILL.md to healthier territory.
4. **Fix `quick_validate.py` allowed properties** -- Correctness bug that will reject valid skills.
5. **Add CHANGELOG.md** -- Practice what you preach.
6. **Extract 3 formal anti-patterns** -- The knowledge is there implicitly; formalize it with the shibboleth template.
7. **Add `allowed-tools` to frontmatter** -- Lead by example.
8. **Date temporal claims** -- "Claude tends to undertrigger" needs a date and version context.

---

## Summary

Anthropic's skill-creator is a solid B-grade skill. Its greatest strength is exceptional self-containment: the eval viewer, benchmark aggregation, blind comparison, and packaging scripts form a genuinely useful toolchain. Its greatest weakness is structural: the SKILL.md is at the size limit, lacks visual diagrams, and omits the formal anti-pattern/shibboleth structures that would make its domain expertise more transferable.

The most impactful single fix is adding a NOT clause to the description. The most impactful structural fix is adding Mermaid diagrams for its three core workflows. Together, these two changes would likely push the score from 7.4 to 8.2.

The validator bug in `quick_validate.py` is a genuine correctness issue that should be addressed regardless of any other changes -- it will cause false rejections for users following the skill-creator's own guidance.
