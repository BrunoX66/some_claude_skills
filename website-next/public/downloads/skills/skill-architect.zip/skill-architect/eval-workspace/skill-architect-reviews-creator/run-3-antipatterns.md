# Anti-Pattern Scan: skill-creator (Anthropic Official)

**Evaluator**: skill-architect
**Date**: 2026-03-06
**Target**: `/Users/erichowens/.claude/plugins/marketplaces/claude-plugins-official/plugins/skill-creator/skills/skill-creator/SKILL.md`
**SKILL.md Line Count**: 479 lines
**Run**: 3 (Anti-Pattern Focus)

---

## Methodology

Each of the 10 anti-patterns from the skill-architect catalog (`references/antipatterns.md`) is evaluated against the skill-creator SKILL.md. Verdicts are **PASS** (no violation), **WARN** (minor concern), or **FAIL** (clear violation with evidence).

---

## Checklist

### 1. Documentation Dump
**Verdict: WARN**

The SKILL.md is 479 lines -- right at the "under 500 lines" threshold. It does NOT read like a generic documentation dump; it contains genuine process knowledge, decision trees, and actionable workflows. However, several sections are very long prose blocks that could be offloaded to reference files:

- Lines 296-318 ("Improving the skill") -- 22 lines of iterative guidance that could live in `references/improvement-guide.md`
- Lines 332-404 ("Description Optimization") -- 73 lines of the description optimization workflow, much of which is mechanistic script-running. This could be a reference file.
- Lines 420-449 ("Claude.ai-specific instructions", "Cowork-Specific Instructions") -- 30 lines of environment-specific adaptations that only apply sometimes.

The core process IS in SKILL.md, and depth IS pushed to `/references` and `/agents`. But the file is bloated by environment-specific contingency sections (Claude.ai, Cowork) that most users never need. Moving those to `references/environment-adaptations.md` would cut ~60 lines.

**Evidence**: 479/500 lines, with ~100 lines of environment-contingent instructions that load unconditionally.

---

### 2. Missing NOT Clause
**Verdict: FAIL**

The description field:

```yaml
description: Create new skills, modify and improve existing skills, and measure skill performance. Use when users want to create a skill from scratch, update or optimize an existing skill, run evals to test a skill, benchmark skill performance with variance analysis, or optimize a skill's description for better triggering accuracy.
```

There is **no NOT clause**. The description says what it does and when to use it, but never says what it is NOT for. This is a textbook violation. Without exclusions, this skill could false-trigger on:

- General code review requests (it touches code quality via evals)
- MCP server implementation (it mentions MCPs in the body)
- Skill *usage* questions (user wants to *use* a skill, not *create* one)
- Testing/QA workflows that aren't about skill evaluation
- Documentation writing (it produces markdown files)

The description should end with something like: `NOT for using existing skills, general code review, MCP server implementation, or non-skill testing workflows.`

**Evidence**: Line 3 -- description has zero exclusions.

---

### 3. Phantom Tools
**Verdict: PASS**

All referenced files exist on disk:

| Reference in SKILL.md | Exists on Disk |
|----------------------|----------------|
| `eval-viewer/generate_review.py` | Yes |
| `references/schemas.md` | Yes |
| `agents/analyzer.md` | Yes |
| `agents/comparator.md` | Yes |
| `agents/grader.md` | Yes |
| `assets/eval_review.html` | Yes |
| `scripts.aggregate_benchmark` | Yes (`scripts/aggregate_benchmark.py`) |
| `scripts.run_loop` | Yes (`scripts/run_loop.py`) |
| `scripts.package_skill` | Yes (`scripts/package_skill.py`) |

One conditional reference (`present_files` tool, line 408) is properly guarded with "only if `present_files` tool is available." This is responsible conditional design.

No phantom tools detected.

**Evidence**: Full glob of skill directory confirms all referenced paths resolve to real files.

---

### 4. Template Soup
**Verdict: PASS**

The skill ships real, working scripts -- not templates. Key files:

- `scripts/aggregate_benchmark.py` (14,386 bytes) -- actual aggregation logic
- `scripts/run_loop.py` (13,685 bytes) -- actual optimization loop
- `scripts/run_eval.py` (11,464 bytes) -- actual eval runner
- `scripts/improve_description.py` (10,723 bytes) -- actual description improver
- `scripts/generate_report.py` (12,847 bytes) -- actual report generator
- `scripts/package_skill.py` (4,234 bytes) -- actual packager
- `scripts/quick_validate.py` (3,972 bytes) -- actual validator
- `eval-viewer/generate_review.py` -- actual HTML viewer generator

These are executable scripts, not stubs or fill-in-the-blank templates. The JSON snippets shown in the SKILL.md (evals.json, eval_metadata.json, timing.json, feedback.json) are documentation of real data formats, not templates for the user to manually instantiate -- the scripts produce and consume them.

**Evidence**: 8 working Python scripts totaling ~70KB of real code.

---

### 5. Overly Permissive Tools
**Verdict: WARN**

The skill-creator's frontmatter has **no `allowed-tools` field at all**. This means it inherits whatever the runtime default is, which is typically unrestricted access to all tools including bare `Bash`.

Given that skill-creator spawns subagents, runs Python scripts, opens browsers, reads/writes files across arbitrary paths, and executes `claude -p` subprocesses, it arguably NEEDS broad permissions. But the lack of any explicit declaration means:

1. There's no documentation of what tools are actually required
2. No principle of least privilege is applied
3. If installed in a restricted environment, the user gets no warning that it needs broad access

A responsible declaration would be something like:
```yaml
allowed-tools: Read,Write,Edit,Bash(python:*,claude:*,nohup:*,kill:*,open:*,cp:*,mkdir:*),Glob,Grep
```

This is a WARN rather than FAIL because the skill's nature (meta-skill that orchestrates other agents) genuinely requires broad access, and the platform may not support granular enough Bash scoping for all its needs.

**Evidence**: No `allowed-tools` field in frontmatter (lines 1-4).

---

### 6. Stale Temporal Knowledge
**Verdict: PASS**

The skill-creator is largely process-oriented rather than technology-specific. It doesn't contain dated framework advice, API version numbers, or technology recommendations that could go stale. Its domain is "how to build and iterate on skills" -- a meta-process that evolves slower than specific technology domains.

The only temporal concern is the `present_files` tool reference (line 408-416), which is a platform feature that may change. But the skill handles this gracefully with a conditional check: "Check whether you have access to the `present_files` tool. If you don't, skip this step."

No dates are given for any advice because none of the advice is time-dependent. The skill's guidance on progressive disclosure, eval methodology, and iteration loops are architectural patterns, not temporal knowledge.

**Evidence**: No technology-specific advice that could become outdated. Process-oriented skill.

---

### 7. Catch-All Skill
**Verdict: PASS**

The skill-creator has a clear, bounded domain: creating, testing, iterating on, and optimizing Claude Agent Skills. It does NOT try to be a general-purpose coding assistant, documentation writer, or testing framework.

Its scope covers:
- Skill SKILL.md drafting
- Test case creation and execution
- Benchmark evaluation (quantitative + qualitative)
- Description optimization for activation
- Skill packaging

These are all facets of one coherent workflow (the skill development lifecycle), not separate domains awkwardly bundled together. The skill doesn't attempt to cover skill *architecture* (that's skill-architect's domain) or skill *grading* at a standalone level.

**Evidence**: Description lists 5 specific use cases, all within the skill development lifecycle. The `pairs-with` field in skill-architect's SKILL.md (line 17) confirms the boundary: "The architect designs skill structure; the creator guides implementation."

---

### 8. Vague Description
**Verdict: WARN**

The description is specific about WHAT the skill does:
> "Create new skills, modify and improve existing skills, and measure skill performance."

And WHEN to use it:
> "Use when users want to create a skill from scratch, update or optimize an existing skill, run evals to test a skill, benchmark skill performance with variance analysis, or optimize a skill's description for better triggering accuracy."

This is good -- it follows the `[What] [When to use]` formula. However:

1. **Missing the NOT clause** (covered in anti-pattern #2)
2. **Slightly wordy** -- the description is 64 words. The "pushy" guidance from the skill-creator itself (line 67) says descriptions should be pushy, but this one is more enumerative than pushy. It lists functions rather than capturing the user's intent with evocative phrasing.
3. **Could be more semantic** -- phrases like "benchmark skill performance with variance analysis" are jargon-heavy. A user who says "is my skill any good?" or "why doesn't my skill trigger?" should also activate this, but the description's language is quite formal.

The description is not *vague* (it's quite specific), but it could be more semantically rich and include the NOT clause. WARN because of the missing exclusions (which is the main risk of false positives), but the WHAT/WHEN parts are solid.

**Evidence**: Line 3 -- 64-word description with good specificity but no exclusions and formal-jargon phrasing.

---

### 9. Eager Loading
**Verdict: PASS**

The skill-creator never instructs agents to "read all reference files before starting." Reference files are pointed to contextually:

- `references/schemas.md` -- "See `references/schemas.md` for the full schema" (lines 161, 231)
- `agents/grader.md` -- "reads `agents/grader.md` and evaluates each assertion" (line 225)
- `agents/comparator.md` -- "Read `agents/comparator.md` and `agents/analyzer.md` for the details" (line 327)
- `agents/analyzer.md` -- "See `agents/analyzer.md` (the 'Analyzing Benchmark Results' section)" (line 234)

Each reference is cited with a specific trigger condition for when to consult it. The Reference Files section at the end (lines 454-462) provides a clean index with purpose descriptions. No eager loading detected.

**Evidence**: Lines 454-462 provide a reference index. All references are cited in context with specific "when to read" triggers.

---

### 10. Prose-Only Processes
**Verdict: FAIL**

This is the most clear-cut violation. The skill-creator describes an elaborate multi-step process with branching logic, parallel execution, and conditional paths -- but uses **zero Mermaid diagrams**. The entire 479-line SKILL.md is prose.

Processes that should be diagrammed:

1. **The core skill creation lifecycle** (lines 10-21): A flowchart or state diagram showing Draft -> Test -> Evaluate -> Improve -> Repeat would be far clearer than the bullet-point description.

2. **The eval execution pipeline** (lines 163-289): This is a 5-step sequential process with parallel branches (with-skill AND baseline runs launched simultaneously), timing capture on notifications, grading, aggregation, and viewer launch. A sequence diagram would make the parallel-then-converge pattern explicit.

3. **The description optimization loop** (lines 332-404): Generate queries -> Review with user -> Run optimization loop -> Apply result. A flowchart with the inner loop (60/40 train/test split, 3x evaluation, improvement proposals, up to 5 iterations) would prevent the agent from losing track of where it is.

4. **The iteration decision tree** (lines 309-322): When to stop iterating. This is literally a decision tree described in prose -- the exact content that should be a Mermaid flowchart.

5. **Environment branching** (lines 420-449): Claude Code vs Claude.ai vs Cowork -- what works and what doesn't in each. A comparison table or mindmap would be more scannable.

The skill-creator's own guidance says "Skills with objectively verifiable outputs benefit from test cases" and it pushes structured processes -- but it doesn't eat its own dog food by rendering those processes as diagrams.

**Evidence**: Zero `mermaid` blocks in 479 lines. Multiple multi-step processes described exclusively in prose.

---

## Summary

| # | Anti-Pattern | Verdict | Severity |
|---|-------------|---------|----------|
| 1 | Documentation Dump | **WARN** | Near line limit (479/500), environment sections bloat |
| 2 | Missing NOT Clause | **FAIL** | No exclusions in description at all |
| 3 | Phantom Tools | **PASS** | All referenced files exist |
| 4 | Template Soup | **PASS** | Ships ~70KB of real working scripts |
| 5 | Overly Permissive Tools | **WARN** | No `allowed-tools` declared |
| 6 | Stale Temporal Knowledge | **PASS** | Process-oriented, no dated advice |
| 7 | Catch-All Skill | **PASS** | Tightly scoped to skill development lifecycle |
| 8 | Vague Description | **WARN** | Good WHAT/WHEN but missing NOT clause and slightly jargon-heavy |
| 9 | Eager Loading | **PASS** | References cited with contextual triggers |
| 10 | Prose-Only Processes | **FAIL** | Zero Mermaid diagrams despite 5+ diagrammable processes |

**Score**: 6 PASS, 2 FAIL, 2 WARN

---

## Recommended Fixes (Priority Order)

### P0: Add NOT clause to description
```yaml
description: Create new skills, modify and improve existing skills, and measure
  skill performance. Use when users want to create a skill from scratch, update or
  optimize an existing skill, run evals to test a skill, benchmark skill performance
  with variance analysis, or optimize a skill's description for better triggering
  accuracy. NOT for using existing skills, general code review, MCP server
  implementation, writing documentation, or non-skill testing workflows.
```

### P0: Add Mermaid diagrams for core processes
At minimum, add:
1. A `flowchart` for the overall skill creation lifecycle (lines 10-21)
2. A `sequenceDiagram` for the eval execution pipeline showing parallel with-skill + baseline spawning, timing capture, grading, aggregation, and viewer launch
3. A `flowchart` for the iteration decision tree (when to stop)

### P1: Declare allowed-tools
```yaml
allowed-tools: Read,Write,Edit,Bash,Glob,Grep
```
Even if broad, making it explicit documents intent.

### P1: Move environment-specific sections to references
Create `references/environment-adaptations.md` with the Claude.ai and Cowork sections. Replace lines 420-449 with:
```markdown
## Environment-Specific Adaptations
See `references/environment-adaptations.md` for Claude.ai and Cowork adjustments.
```
This saves ~30 lines and avoids loading irrelevant instructions.

---

## Anti-Pattern Cross-Reference

The skill-creator ironically contains guidance that would prevent its own violations. Line 67 recommends "pushy" descriptions. Line 96 says "Keep SKILL.md under 500 lines." But it doesn't follow its own template (no NOT clause in the example on line 67, no Mermaid diagrams despite recommending structured processes). This is a case of "do as I say, not as I do" -- the cobbler's children have no shoes.
