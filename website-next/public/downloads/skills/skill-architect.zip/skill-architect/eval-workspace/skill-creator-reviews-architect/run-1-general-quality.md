# General Quality Audit: skill-architect

**Evaluator**: Claude Opus 4.6, applying Anthropic's skill-creator methodology
**Date**: 2026-03-06
**Skill Version**: v2.1.1
**SKILL.md Line Count**: 499

---

## Overall Score: 7.5 / 10 (Grade B)

A genuinely impressive meta-skill with deep domain expertise, excellent progressive disclosure architecture, and strong reference material. However, it is undermined by **phantom tool references** (3 of 4 referenced scripts do not exist), sits right at its own stated line limit (499 of 500), and has a description that, while thorough, tests the boundaries of being a "mini-manual" -- the very anti-pattern it warns against. The skill practices most of what it preaches, but the phantom scripts are a significant self-contradiction.

---

## Category Scores

| Category | Score | Notes |
|----------|-------|-------|
| Activation Precision | 8/10 | Strong description with NOT clause, clear boundaries |
| Domain Expertise Depth | 9/10 | Exceptional: shibboleths, temporal knowledge, KE methods, case studies |
| Progressive Disclosure | 7/10 | Good architecture, but SKILL.md at 499 lines is borderline |
| Self-Containment | 5/10 | 3 of 4 referenced scripts are phantoms -- violates its own anti-pattern #3 |
| Maintainability | 8/10 | Versioned, comprehensive CHANGELOG, modular references |
| **Composite** | **7.5/10** | |

---

## Detailed Findings

### 1. Activation Precision (8/10)

**Strengths:**

- The description follows the `[What] [When to use] NOT for [Exclusions]` formula that the skill itself prescribes:
  > "Design, create, audit, and improve Claude Agent Skills with expert-level progressive disclosure. Use when building new skills, reviewing existing skills, debugging activation failures, encoding domain expertise, designing skills for subagent consumption, or understanding platform constraints and distribution surfaces. NOT for general Claude Code features, runtime debugging, non-skill coding, or MCP server implementation."

- The NOT clause is specific and meaningful -- it carves out adjacent domains (general Claude Code features, runtime debugging, MCP implementation) that would otherwise cause false positives.

- The `argument-hint` field provides useful autocomplete guidance: `[skill-path-or-name] [action: create|audit|improve|debug]`.

- The `pairs-with` metadata is well-considered and uses concrete `reason` fields.

**Weaknesses:**

- The description is 287 characters, which is within the 1024-char limit but could be viewed as approaching the "mini-manual" anti-pattern the skill itself warns about. The "or understanding platform constraints and distribution surfaces" clause is arguably too specific for a description and belongs in the SKILL.md body.

- The skill's own `references/description-guide.md` recommends 25-50 words. This description is approximately 55 words -- slightly over the ideal range.

- The name `skill-architect` vs the paired `skill-creator` could create confusion about when each activates. The pairing note helps, but a user saying "create a skill" might reasonably trigger either.

**Activation Test (hypothetical):**

| Query | Should Activate? | Likely Result |
|-------|------------------|---------------|
| "Create a new skill for code review" | Yes | Correct -- "create" + "skill" |
| "Audit my existing skill" | Yes | Correct -- "audit" + "skill" |
| "Why isn't my skill triggering?" | Yes | Correct -- maps to "debugging activation failures" |
| "Help me set up an MCP server" | No | Correct -- explicitly excluded |
| "Review this Python code" | No | Correct -- "non-skill coding" excluded |
| "How do I use Claude Code slash commands?" | No | Correct -- "general Claude Code features" excluded |
| "Design a skill for my subagents" | Yes | Correct -- explicitly included |
| "Fix this TypeScript error" | No | Correct -- "runtime debugging" excluded |

Estimated activation precision: ~90%. The description is well-crafted.

---

### 2. Domain Expertise Depth (9/10)

**Strengths:**

This is the skill's standout quality. It encodes genuinely expert-level knowledge across multiple dimensions:

- **Shibboleth template** (lines 354-362): The Novice/Expert/Timeline/LLM-mistake/Detection template is a genuinely useful framework for encoding temporal domain knowledge. This is not something you would find in a generic "how to write documentation" guide.

- **Knowledge engineering methods** (`references/knowledge-engineering.md`): This is remarkable. It covers Protocol Analysis, Repertory Grid Technique, Card Sorting, Critical Incident Technique, and Concept Mapping -- with real-world examples from Boeing, University of Southampton, and healthcare research. The section on "The Aha! Moment Problem" and "Structured Ignorance Management" shows deep understanding of knowledge acquisition theory. This alone would be valuable as a standalone skill.

- **Anti-pattern catalog** (`references/antipatterns.md`): Four case studies with real symptoms, root causes, and resolutions. The "Photo Expert Explosion" case study is an excellent example of the "Everything Skill" anti-pattern.

- **Extension taxonomy** (`references/claude-extension-taxonomy.md`): Comprehensive and current (March 2026) coverage of all 7 Claude extension types with a clear graduation path. This is practical, up-to-date knowledge that prevents the "MCP for Everything" anti-pattern.

- **Description formula**: The bad-to-good examples in both SKILL.md (lines 156-163) and `references/description-guide.md` are genuinely useful. They cover 7 distinct failure modes with concrete before/after examples.

- **Platform constraints table** (lines 130-141): Precise, actionable limits (64-char name, 1024-char description, 8MB upload, 8 skills per API request). This is the kind of knowledge that prevents wasted effort.

- **23 Mermaid diagram types**: The comprehensive table mapping content types to diagram types (lines 302-326) is an excellent reference that goes beyond what most skills would include.

**Weaknesses:**

- Some of the anti-pattern examples in `references/antipatterns.md` (CLIP limitations, Redux vs. Zustand, Class Components) are general web development knowledge, not skill-specific shibboleths. They demonstrate the shibboleth pattern well but are arguably padding.

- The "AI-Native Knowledge Acquisition" section in `references/knowledge-engineering.md` references a `very-long-text-summarization` skill that may or may not exist -- if it does not exist, this is another phantom reference.

- The scoring rubric (`references/scoring-rubric.md`) references `scripts/check_self_contained.py` which does not exist.

---

### 3. Progressive Disclosure (7/10)

**Strengths:**

- The three-layer architecture (metadata, SKILL.md, references) is well-defined and well-explained (lines 68-81).

- The reference file index at the bottom of SKILL.md (lines 482-499) follows the skill's own prescription: each file has a 1-line "Consult When" description. This is exemplary.

- The reference files are genuinely useful deep dives that would waste context if inlined. The `knowledge-engineering.md` file alone is worth the progressive disclosure architecture.

- 13 reference files cover distinct, well-scoped topics with minimal overlap.

**Weaknesses:**

- **SKILL.md is 499 lines** -- exactly 1 line under the 500-line limit the skill itself prescribes. This is technically compliant but is clearly straining against the constraint. The skill's own scoring rubric (`references/scoring-rubric.md`) gives a 7-8 score for "<300 lines" and a 9-10 for "<200 lines." By its own grading, the SKILL.md is in the 5-6 range for this subcategory.

- Several sections in SKILL.md could be moved to references without loss:
  - The full "Mermaid Diagram Types" table (lines 298-326, ~30 lines) could move to `references/visual-artifacts.md` with a summary in SKILL.md.
  - The "Common Rejection Causes" table (lines 452-464, ~15 lines) overlaps significantly with the "Anti-Pattern Summary" table and the frontmatter rules. This is near-duplication.
  - The "Platform Constraints" table (lines 130-141) could be a reference file, with only the most critical constraints (name format, description length) kept in SKILL.md.

- The SKILL.md includes content at different levels of granularity. The "Philosophy" section (line 30) is high-level, the "Common Rejection Causes" (line 452) is very granular. This inconsistency in abstraction level within SKILL.md is a mild progressive disclosure violation.

---

### 4. Self-Containment (5/10)

**This is the skill's most significant weakness.**

The SKILL.md references the following scripts:

| Script | Referenced At | Exists? |
|--------|---------------|---------|
| `scripts/validate_skill.py` | Lines 249, 446, 465 | **NO** |
| `scripts/check_self_contained.py` | Line 250 | **NO** |
| `scripts/init_skill.py` | Line 224 | **NO** |
| `scripts/validate_mermaid.py` | Lines 446, 499 | Yes |

Three of four referenced scripts are **phantoms**. This is a direct violation of the skill's own Anti-Pattern #3 ("Phantom Tools"):

> "Only reference files that exist and work" (line 418)

And from the anti-patterns reference file, Case Study 2 ("The Phantom MCP"):

> "Claude confidently told users to run non-existent commands... Trust in skill ecosystem damaged... Don't promise tools you don't deliver."

The irony is severe. A meta-skill about creating skills commits the exact anti-pattern it warns against. An agent following this skill's instructions would attempt to run `scripts/validate_skill.py` and fail, wasting tool calls and user trust.

The `validate_mermaid.py` script that DOES exist is well-written: 649 lines of Python with proper CLI interface, comprehensive validation of all 23 Mermaid diagram types, JSON output option, and graceful error handling. It is a model of what the other scripts should be.

**The scoring rubric's own check for this category**: "Run `check_self_contained.py`" -- which itself does not exist.

---

### 5. Maintainability (8/10)

**Strengths:**

- **CHANGELOG.md** is exemplary. It tracks 4 versions (v1.0.0 through v2.1.1) with detailed change descriptions organized by category (Major Improvements, New Reference Files, Removed, Philosophy Update).

- **Semantic versioning** is properly applied. The jump from v1.0.0 to v2.0.0 reflects a major rewrite (637 to 350 lines), v2.1.0 adds features (visual artifacts), v2.1.1 is clarifications.

- **Modular reference files** make updates targeted. Updating the Claude extension taxonomy only requires editing one file, not rewriting SKILL.md.

- **Temporal markers** in reference files (e.g., "Last updated: March 2026" in `claude-extension-taxonomy.md`) follow the skill's own prescription for dating knowledge.

**Weaknesses:**

- The CHANGELOG records v2.0.0 as reducing SKILL.md from "637 lines to 350 lines." The current version is 499 lines. That means approximately 150 lines have crept back in between v2.0.0 and v2.1.1, suggesting scope creep. The CHANGELOG entries for v2.1.0 and v2.1.1 don't note the line count increase.

- No automated CI validation. The skill mentions running validation scripts but doesn't include a CI configuration or pre-commit hook that would enforce its own standards.

---

## Structural Issues

### 1. The init_skill.py Confusion

Lines 222-226 reference `scripts/init_skill.py` as if it is bundled with skill-architect:

```
### Step 3: Initialize
scripts/init_skill.py <skill-name> --path <output-directory>
```

However, this script appears to come from Anthropic's official `skill-creator` skill (the `plugin-dev` plugin includes an `init_skill.py`). The skill-architect SKILL.md does not clarify whether this is its own script or an external dependency. If external, it should document where to find it. If internal, it should ship it.

### 2. Overlap with skill-creator

The skill-architect explicitly `pairs-with` skill-creator, stating: "The architect designs skill structure; the creator guides implementation following those patterns." But reading both side by side, there is significant overlap:

- Both define a 6-step creation process
- Both cover SKILL.md structure
- Both discuss progressive disclosure
- Both cover scripts, references, and assets

The differentiation is unclear. A user or agent encountering both skills would struggle to know which to invoke. The skill-architect is more comprehensive and opinionated (it adds anti-patterns, shibboleths, Mermaid, platform constraints, subagent design, knowledge engineering), while skill-creator is more procedural and conservative. But the core workflows are substantially similar.

This is arguably the "Overlapping Skills" problem that the description-guide warns about.

### 3. HTML Entities

Lines 59, 77, 432 use `&lt;` instead of `<`. This is likely an encoding artifact that could cause confusion if an agent interprets these literally rather than as HTML entities.

---

## Comparative Analysis: skill-architect vs. skill-creator (Anthropic official)

| Dimension | skill-creator (Anthropic) | skill-architect (custom) |
|-----------|--------------------------|--------------------------|
| Line count | ~210 lines | 499 lines |
| Description formula | Basic ("Be specific") | Detailed with 7 bad-to-good examples |
| Anti-patterns | None | 10 named anti-patterns + case studies |
| Shibboleths | None | Template + examples |
| Temporal knowledge | None | Timeline template, React/CLIP/Redux examples |
| Mermaid guidance | None | 23 diagram types, validation script |
| Subagent design | None | 3-layer loading, prompt structure |
| Knowledge engineering | None | 5 KE methods with real-world examples |
| Platform constraints | None | Full constraint table |
| Extension taxonomy | None | 7-type taxonomy with graduation path |
| Plugin architecture | None | Full guide |
| Working scripts | init_skill.py, package_skill.py | validate_mermaid.py (3 others are phantoms) |
| Writing style | Third-person prescribed | Imperative prescribed |

The skill-architect is substantially more comprehensive. It represents a genuine evolution beyond the official skill-creator, encoding real domain expertise that the official version lacks. However, the official skill-creator has a cleaner self-containment story (its scripts actually exist and work).

---

## Recommendations (Priority Order)

### Critical (Must Fix)

1. **Create or remove phantom scripts.** Either implement `validate_skill.py`, `check_self_contained.py`, and `init_skill.py`, or remove all references to them from SKILL.md. The current state is a direct violation of Anti-Pattern #3 and undermines the skill's credibility. If the intent is to reference scripts from the official `plugin-dev` plugin, document that dependency explicitly.

### High Priority

2. **Reduce SKILL.md to <400 lines.** The current 499-line count strains against the 500-line rule and scores poorly by the skill's own rubric. Candidates for extraction to references:
   - Full Mermaid diagram type table (lines 298-326) -> already covered in `references/visual-artifacts.md`
   - Common Rejection Causes table (lines 452-464) -> merge into `references/antipatterns.md`
   - Platform Constraints (lines 130-141) -> new `references/platform-constraints.md` or merge into taxonomy

3. **Clarify relationship with skill-creator.** The `pairs-with` declaration says they complement each other, but the overlap is substantial. Either document the clear division of responsibility (architect = design/audit, creator = implementation/packaging) or acknowledge that skill-architect supersedes skill-creator for users who have both.

### Medium Priority

4. **Fix HTML entities.** Replace `&lt;` with `<` on lines 59, 77, and 432. Agents may interpret these literally.

5. **Add activation test queries.** The skill prescribes "Write 5 queries that should trigger and 5 that shouldn't" (line 62) but does not include its own activation test set. Practice what you preach.

6. **Address line count creep in CHANGELOG.** Note in the CHANGELOG that SKILL.md grew from ~350 lines (v2.0.0) to 499 lines (v2.1.1). This transparency helps future maintainers understand the scope trajectory.

### Low Priority

7. **Consider adding `disable-model-invocation: false`** explicitly to clarify that this skill should auto-trigger on matching queries, not just respond to `/skill-architect`.

8. **Verify `very-long-text-summarization` reference** in `knowledge-engineering.md`. If this skill does not exist in the user's catalog, it is another phantom reference (albeit in a deep reference file, so lower severity).

---

## Summary

skill-architect is a genuinely expert-level meta-skill that encodes deep knowledge about skill creation, domain expertise extraction, platform constraints, and progressive disclosure architecture. Its reference library is exceptional -- the knowledge-engineering guide alone is a unique contribution. The core SKILL.md is well-structured with clear sections, good Mermaid usage, and a coherent philosophy.

The primary failure is ironic: a skill that teaches "no phantom tools" has three phantom tool references. This is both the easiest thing to fix and the most damaging to credibility. Fix the phantoms, trim 100 lines from SKILL.md, and this is a 9/10 skill.

**Final Grade: 7.5/10 (B) -- held back by self-containment failures, would be A-tier with phantom scripts resolved and SKILL.md trimmed.**
