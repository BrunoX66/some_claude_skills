# Skill-Creator Reviews Skill-Architect: Bundled Resources Evaluation

**Run 3 — Resource Quality Assessment**
**Date**: 2026-03-06
**Evaluator**: skill-creator methodology applied to skill-architect v2.1.1
**Score: 8.2 / 10**

---

## Executive Summary

Skill-architect's bundled resources are one of the strongest reference libraries in the skill ecosystem. Thirteen reference files and one working script cover the full design space from description writing to plugin distribution, with progressive disclosure implemented correctly at both the SKILL.md-to-reference boundary and within individual reference files. The resources genuinely add value — they aren't padding. However, the skill suffers from three phantom script references, one script that exists only as a template concern, a visual-artifacts reference that is nearly twice the length of SKILL.md itself (creating a context-cost risk), and an incomplete README that doesn't reflect the full file tree. These are fixable issues against a strong foundation.

---

## Resource Inventory

### Directory Structure

```
skill-architect/
├── SKILL.md                  (499 lines)
├── CHANGELOG.md              (107 lines)
├── README.md                 (132 lines)
├── scripts/
│   └── validate_mermaid.py   (649 lines — working Python)
└── references/
    ├── antipatterns.md               (570 lines)
    ├── claude-extension-taxonomy.md  (363 lines)
    ├── description-guide.md          (219 lines)
    ├── knowledge-engineering.md      (279 lines)
    ├── mcp-template.md               (271 lines)
    ├── plugin-architecture.md        (320 lines)
    ├── scoring-rubric.md             (109 lines)
    ├── self-contained-tools.md       (381 lines)
    ├── skill-composition.md          (132 lines)
    ├── skill-lifecycle.md            (173 lines)
    ├── subagent-design.md            (367 lines)
    ├── subagent-template.md          (450 lines)
    └── visual-artifacts.md           (959 lines)
```

**Total reference content**: ~4,593 lines across 13 files
**Total bundled resources**: ~5,380 lines (references + scripts + CHANGELOG + README)

---

## Category-by-Category Assessment

### 1. Progressive Disclosure Implementation (9/10)

**Strengths:**

- SKILL.md stays at exactly 499 lines — right at the self-imposed <500 line limit, which shows discipline. The core process, anti-pattern summary table, frontmatter rules, and reference index all live in the main file. Deep dives are consistently deferred.

- Every single reference file is listed in SKILL.md's "Reference Files" table (lines 480-499) with a one-line "Consult When" description. This is textbook progressive disclosure — the agent knows what exists and when to reach for it without having to load any of it.

- The three-layer architecture (metadata -> SKILL.md -> references) is not just described; it's practiced. The SKILL.md has summary tables for anti-patterns, frontmatter fields, and platform constraints. The references have the full case studies, templates, and worked examples.

- SKILL.md explicitly instructs: "Never instruct 'read all reference files before starting.' Instead: 'Read only the files relevant to the current step.'" This lazy-loading principle is both taught and modeled.

**Weaknesses:**

- `visual-artifacts.md` at 959 lines is nearly twice the length of SKILL.md itself. When an agent decides it needs this reference, it will consume a large context chunk. The file could benefit from being split into a quick-reference section (the decision table + top 5 diagram types) and an extended catalog (the remaining 18 types with examples). Alternatively, add a note in SKILL.md: "Skim headings first; most skills only need flowchart, sequence, and state."

- The reference index in SKILL.md lists `scripts/validate_mermaid.py` alongside the reference files, which slightly muddies the distinction between "files to read" and "files to run."

### 2. Resource Organization (8/10)

**Strengths:**

- Clean separation of concerns. Each reference file has a single, clear topic. There is no content that belongs in two files.

- Files are named descriptively: `description-guide.md`, `self-contained-tools.md`, `skill-lifecycle.md`. An agent can infer purpose from the filename alone.

- Internal structure of reference files is consistent: each starts with a title, has a purpose statement, uses tables for comparisons, includes code examples where appropriate, and ends with checklists or summaries.

- CHANGELOG.md is well-maintained with semantic versioning, grouped changes, and clear migration notes. The v2.0.0 entry documents what was removed and why — essential for understanding the current structure.

**Weaknesses:**

- No `assets/` directory exists, nor is one needed for this skill. This is fine — the skill-creator methodology says to delete empty example directories. Score not penalized.

- README.md's file tree (lines 82-95) is incomplete. It omits `knowledge-engineering.md`, `plugin-architecture.md`, `scoring-rubric.md`, `skill-composition.md`, `skill-lifecycle.md`, and `claude-extension-taxonomy.md`. This is a documentation drift problem — the README was written at v2.0.0 and never updated when later references were added.

### 3. Phantom References (6/10)

**This is the most significant issue.**

SKILL.md references three scripts that do not exist in the skill-architect directory:

| Referenced Script | Where Referenced | Exists? |
|---|---|---|
| `scripts/validate_skill.py` | Lines 249, 446, 465 | NO — phantom |
| `scripts/check_self_contained.py` | Line 250 | NO — phantom |
| `scripts/init_skill.py` | Line 224 | NO — lives in skill-creator |

Only `scripts/validate_mermaid.py` actually exists in skill-architect.

**Impact**: This is exactly the "Phantom Tools" anti-pattern that skill-architect itself warns against in anti-pattern #3 (line 418). An agent following the creation process in Step 5 will attempt to run `python scripts/validate_skill.py <path>` and fail. The irony of the meta-skill violating its own cardinal rule is notable.

**Mitigating factor**: `init_skill.py` is from the `skill-creator` companion skill (it exists at `/Users/erichowens/.claude/skills/skill-creator/scripts/init_skill.py`). The `pairs-with` frontmatter correctly identifies skill-creator as a companion. However, the SKILL.md doesn't clarify that `init_skill.py` comes from a different skill — a reader would assume it's local.

**The validate_skill.py and check_self_contained.py references are unambiguously phantom.** They are referenced as if they exist locally, but they don't. They should either be created, removed, or clearly attributed to an external source.

### 4. Script Quality: validate_mermaid.py (9/10)

**Strengths:**

- This is a genuinely useful, working script — not a template. 649 lines of real Python with:
  - All 23 Mermaid diagram types recognized (including beta types: packet-beta, radar, treemap, kanban)
  - Structural validation: balanced subgraph/end blocks, balanced curly braces, direction suffixes
  - Diagram-type-specific checks: sequence diagram lifelines, ER relationship labels, Sankey CSV format
  - Multiple scan modes: single file, directory, skill, all-skills
  - JSON output mode for CI/CD integration
  - Clean CLI with argparse, clear help text, and `--errors-only` / `--recursive` flags

- Error handling is solid: graceful on non-markdown files, proper exit codes (0 for pass, 1 for fail), no external dependencies (stdlib only).

- The script eats its own cooking: it could be run against the skill-architect's own SKILL.md and references.

**Weaknesses:**

- The script could benefit from a shebang + `chmod +x` for direct execution (`./scripts/validate_mermaid.py`), but this is a minor usability note.

- The `_check_node_ids` function uses a threshold of 3 for duplicate node IDs, which may produce false positives in larger flowcharts where nodes are referenced from multiple edges. The threshold could be configurable.

- Print formatting uses hardcoded spaces instead of icons for error/warning severity (line 565-566: `icon = "  "` for both error and warning). This appears to be a rendering issue from HTML entity stripping — the original likely had emoji icons that got sanitized.

### 5. Reference File Quality — Sampled Deep Dive

#### antipatterns.md (8/10)

Well-structured with 4 case studies from real-world failures (Photo Expert Explosion, Phantom MCP, Time Bomb, Activation Black Hole). Each follows the shibboleth template: Novice thinking, Expert reality, Timeline, LLM mistake. The ML/AI section (CLIP limitations, embedding model selection) contains genuinely non-obvious knowledge that LLMs would get wrong. The temporal patterns section provides an excellent template for future entries.

Minor issue: The "Contributing" section at the end is somewhat aspirational since there's no formal contribution mechanism. The case study for "The Phantom MCP" references `check_self_contained.py` as the resolution — which is itself a phantom in this skill.

#### visual-artifacts.md (7/10)

The most comprehensive Mermaid reference available in any skill. Covers all 23 diagram types with examples, node shape catalogs, edge style references, and a decision matrix. The "Can Agents Actually Interpret Mermaid?" section is excellent — it makes the case that Mermaid is not just for humans but is actually more precise for agents than prose.

However, at 959 lines it is the longest single reference file and likely to consume significant context when loaded. The file would benefit from a "Quick Reference" section at the top (the decision table from lines 836-862 + the 3 most common types) followed by a clearly labeled "Extended Catalog" section. An agent doing a quick audit doesn't need to see all 23 types; it needs the top 5 and the decision table.

The raw-vs-quoted Mermaid distinction is well-explained and important — it prevents a common mistake where skills accidentally quote their own diagrams, turning operative instructions into illustrative examples.

#### self-contained-tools.md (8/10)

Practical, action-oriented. The Script Requirements checklist (actually work, minimal deps, clear interface, error handling, README) is simple and correct. The MCP Server section provides a complete minimal example. The anti-patterns section (Phantom Tools, Template Soup, Dependency Hell, MCP Without Purpose) directly mirrors and extends what's in SKILL.md.

The Subagents section is thinner than the others but appropriately defers to `subagent-design.md` for depth. The skill cross-references table at the end (clip-aware-embeddings, site-reliability-engineer, skill-coach) provides concrete examples of self-contained skills in the wild.

### 6. Reference File Coverage Analysis

| Domain | Reference File | Coverage |
|---|---|---|
| Description writing | description-guide.md | Excellent — 7 bad-to-good examples, testing checklist |
| Anti-patterns / shibboleths | antipatterns.md | Excellent — 4 domains, 4 case studies, temporal patterns |
| Visual artifacts | visual-artifacts.md | Comprehensive — all 23 types with examples |
| Self-contained tools | self-contained-tools.md | Good — scripts, MCP, subagents covered |
| Subagent design | subagent-design.md | Good — 3 loading layers, prompt structure, patterns |
| Subagent templates | subagent-template.md | Good — single agent + pipeline templates with examples |
| Extension taxonomy | claude-extension-taxonomy.md | Excellent — 7 types with decision matrix, March 2026 current |
| Plugin architecture | plugin-architecture.md | Good — full manifest schema, distribution methods, March 2026 current |
| MCP server template | mcp-template.md | Adequate — minimal starter, covers basics |
| Scoring rubric | scoring-rubric.md | Good — 5 categories, 0-10 scale, composite grading |
| Skill composition | skill-composition.md | Adequate — dependency types, anti-patterns, brief |
| Skill lifecycle | skill-lifecycle.md | Adequate — 5 stages, maintenance checklists |
| Knowledge engineering | knowledge-engineering.md | Excellent — 5 KE methods, AI-native techniques, book list |

**Gap analysis**: No reference file covers testing/activation validation in depth. The scoring rubric mentions activation testing but there's no dedicated "how to test your skill's activation" guide with worked examples. Given that activation precision is the #1 success metric, this seems like a missing reference.

### 7. Value Assessment: Are Resources Necessary?

For each reference, I evaluated: "Would this skill work as well if this file didn't exist?"

| File | Verdict | Reasoning |
|---|---|---|
| antipatterns.md | Essential | Case studies and shibboleths are the skill's core differentiator |
| visual-artifacts.md | High value | Without it, Mermaid guidance would have to live in SKILL.md (bloating it) or not exist |
| description-guide.md | High value | 7 bad-to-good examples are the most actionable content in the skill |
| self-contained-tools.md | High value | Concrete patterns for scripts/MCP/subagents |
| subagent-design.md | High value | Unique content not available elsewhere |
| claude-extension-taxonomy.md | High value | Prevents the "MCP for everything" anti-pattern; current as of March 2026 |
| knowledge-engineering.md | Moderate value | Sophisticated KE methods — but how often does a skill-builder use repertory grids? |
| plugin-architecture.md | Moderate value | Valuable for distribution; not needed for most skill-building |
| subagent-template.md | Moderate value | Copy-paste templates — useful but could be shorter |
| mcp-template.md | Moderate value | Minimal starter template — useful when needed, ignorable otherwise |
| scoring-rubric.md | Moderate value | Quantifies quality — more useful for audits than creation |
| skill-composition.md | Low-moderate | Brief, somewhat thin — the composition topic deserves more depth or integration into another file |
| skill-lifecycle.md | Low-moderate | Maintenance guidance is good to have but rarely consulted during creation |

No file is pure padding. The lowest-value files (skill-composition.md, skill-lifecycle.md) are also the shortest (132 and 173 lines), so their context cost is minimal. The highest-value files (antipatterns.md, visual-artifacts.md, description-guide.md) justify their length with worked examples and actionable content.

---

## Findings Summary

### What's Working Well

1. **Progressive disclosure is practiced, not just preached.** The three-layer architecture is clean. SKILL.md has summaries; references have depth. The reference index in SKILL.md is complete with "Consult When" guidance for each file.

2. **No content duplication.** The v2.0.0 rewrite explicitly removed duplicated case studies from SKILL.md (they already lived in antipatterns.md). Each piece of knowledge has a single canonical location.

3. **validate_mermaid.py is a genuine working tool.** 649 lines of production-quality Python with no external dependencies, comprehensive coverage of all 23 Mermaid types, multiple scan modes, and JSON output for CI. This is what "self-contained" means.

4. **Reference files follow consistent internal structure.** Title, purpose, tables, examples, checklists. An agent can navigate any of them predictably.

5. **Temporal currency.** `claude-extension-taxonomy.md` and `plugin-architecture.md` are both marked "Last updated: March 2026" and include content about hooks lifecycle events, Agent SDK, and plugin marketplaces that reflects the current platform state.

6. **Knowledge-engineering.md is genuinely novel.** Protocol analysis, repertory grids, critical incident technique, concept mapping — this is academic KE methodology adapted for skill building. The Boeing case study and Flanagan WWII pilot study references ground it in real research. The AI-native techniques section (corpus distillation, interview simulation) is original thinking.

### What Needs Fixing

1. **Three phantom script references.** `scripts/validate_skill.py`, `scripts/check_self_contained.py`, and (arguably) `scripts/init_skill.py` are referenced in SKILL.md but do not exist in this skill's `scripts/` directory. This directly violates anti-pattern #3 (Phantom Tools). Priority: HIGH.

2. **visual-artifacts.md is too large for single-load.** At 959 lines, it's the largest reference file by far and risks consuming significant context. Should either be split or have a "Quick Reference" section surfaced at the top. Priority: MEDIUM.

3. **README.md file tree is stale.** Missing 6 of 13 reference files. The README was last coherent at v2.0.0 but has drifted as references were added. Priority: LOW (doesn't affect agent behavior, only human navigation).

4. **Missing activation testing reference.** Given that activation precision is the #1 success metric and the SKILL.md's Quick Wins section recommends "Test activation — write 5 queries that should trigger and 5 that shouldn't," there should be a `references/activation-testing.md` with worked examples of testing descriptions against query sets. Priority: MEDIUM.

5. **validate_mermaid.py severity icons are blank.** Line 565-566 has `icon = "  "` for both errors and warnings — likely a rendering artifact. Should use text labels like `[ERR]` and `[WRN]` for terminal compatibility. Priority: LOW.

---

## Scoring Breakdown

| Category | Score | Notes |
|---|---|---|
| Progressive disclosure implementation | 9/10 | Textbook three-layer architecture; only ding is visual-artifacts.md size |
| Resource organization | 8/10 | Clean naming, consistent structure, stale README |
| Phantom reference avoidance | 6/10 | Three phantom scripts — the meta-skill's own worst anti-pattern |
| Script quality | 9/10 | validate_mermaid.py is production-grade |
| Reference file quality (sampled) | 8/10 | Strong across the board; visual-artifacts.md needs trimming |
| Value justification | 9/10 | No padding; every file serves a purpose |
| Completeness | 8/10 | Missing activation testing guide |

**Composite: 8.2 / 10 (Grade: B+)**

The resources are well-organized, genuinely valuable, and implement progressive disclosure correctly. The phantom script references are the primary drag on the score — particularly ironic for a skill that explicitly catalogs "Phantom Tools" as anti-pattern #3. Fixing the three phantoms and trimming visual-artifacts.md would push this to a solid A.

---

## Recommended Actions (Priority Order)

1. **Fix phantom scripts** — Either create `validate_skill.py` and `check_self_contained.py` locally, or clarify in SKILL.md that these are external tools (with installation instructions). For `init_skill.py`, add a note: "From the skill-creator companion skill."

2. **Add quick-reference header to visual-artifacts.md** — Put the decision table and top 5 diagram types (flowchart, sequence, state, ER, timeline) in the first 100 lines. Label the remaining 18 types as "Extended Catalog" so agents can stop reading early.

3. **Update README.md file tree** — Add the 6 missing reference files.

4. **Create references/activation-testing.md** — Worked examples of testing skill descriptions against should-trigger/shouldn't-trigger query sets. Include a mini-methodology and sample test matrix.

5. **Fix validate_mermaid.py icon rendering** — Replace blank icon strings with `[ERR]`/`[WRN]` text labels.
