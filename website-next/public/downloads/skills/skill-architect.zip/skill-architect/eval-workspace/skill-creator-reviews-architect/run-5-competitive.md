# Competitive Analysis: skill-creator vs. skill-architect

**Evaluator**: Claude Opus 4.6, applying skill-creator methodology
**Date**: 2026-03-06
**Question**: If you were building a skill from scratch, which would you rather have guiding you and why?

---

## Head-to-Head Comparison Table

| Dimension | skill-creator (Anthropic official) | skill-architect (custom) | Winner |
|---|---|---|---|
| **Primary mission** | End-to-end skill creation + iterative improvement via eval loops | Comprehensive reference manual for skill design, audit, and improvement | Tie (different scopes) |
| **Description quality guidance** | Good -- "pushy" descriptions, realistic examples, undertriggering warning | Excellent -- formal formula, 7 bad/good pairs, full reference file, anti-query testing | skill-architect |
| **Eval/testing infrastructure** | Exceptional -- subagent-spawned test runs, baseline comparisons, blind A/B, grading agents, HTML viewer, benchmark aggregation, description optimization loop with train/test split | Minimal -- "write 5 queries that should trigger and 5 that shouldn't", manual validation scripts | skill-creator |
| **Working scripts** | 8 Python scripts (run_eval, run_loop, aggregate_benchmark, improve_description, package_skill, generate_report, quick_validate, utils) + HTML viewer + eval review template | 1 Python script (validate_mermaid.py) | skill-creator |
| **Subagent infrastructure** | 3 dedicated agents (grader, comparator, analyzer) with full JSON schemas | Subagent design guidance (how to write skills FOR subagents), no dedicated agents | skill-creator |
| **Progressive disclosure guidance** | Good -- 3-level loading, 500-line limit, domain organization pattern | Excellent -- 3-layer table with token counts, "never read all files first", explicit rules for when agents should skim vs. drill in | skill-architect |
| **Anti-pattern/shibboleth depth** | Light -- warns about overfitting, explains "why" over "MUST", but no formal anti-pattern framework | Deep -- formal shibboleth template (Novice/Expert/Timeline/LLM mistake/Detection), 10 named anti-patterns, full reference file with case studies | skill-architect |
| **Knowledge engineering** | None | Extensive -- Protocol Analysis, Repertory Grid, Card Sorting, Critical Incident Technique, Concept Mapping, Aha! Moment extraction, AI-native techniques (corpus distillation, interview simulation, cross-source triangulation) | skill-architect |
| **Platform constraints** | Brief mentions (name format, 500 lines) | Comprehensive table (64-char names, 1024-char descriptions, 8MB upload, 8 skills/request, cross-surface non-sync, reserved words, XML tag prohibition) | skill-architect |
| **Extension taxonomy** | Not addressed | Full 7-type taxonomy (Skills, Plugins, MCPs, Scripts, Slash Commands, Hooks, Agent SDK) with evolution path and decision tree | skill-architect |
| **Mermaid/visual guidance** | None | All 23 Mermaid diagram types cataloged with use-case mapping, YAML frontmatter guidance, validation script | skill-architect |
| **Frontmatter field coverage** | name, description, compatibility mentioned | All 14 fields documented with purpose, examples, and gotchas; common rejection causes table; invalid-key warnings | skill-architect |
| **Writing style guidance** | Excellent -- "explain the why", theory of mind, avoid heavy-handed MUSTs, generalize from examples, keep prompts lean, read transcripts for wasted work | Good -- imperative form, but more prescriptive/formulaic | skill-creator |
| **Iteration methodology** | Rigorous -- spawn with-skill + baseline, grade, aggregate, show human, read feedback, improve, repeat until happy | Light -- 6-step create, validate, iterate from real-world use | skill-creator |
| **Audience calibration** | Explicitly addresses non-technical users ("plumbers opening terminals"), adjusts jargon | Assumes technical audience comfortable with YAML, Mermaid, Python, knowledge engineering concepts | skill-creator |
| **Claude.ai / Cowork support** | Explicit sections for both environments with adapted workflows | Not addressed | skill-creator |
| **Scoring rubric** | Implicit in grading agents (pass/fail assertions) | Explicit 5-category 0-10 rubric (Activation Precision, Domain Expertise Depth, Progressive Disclosure, Self-Containment, Maintainability) with grade mapping | skill-architect |
| **Description optimization** | Automated loop with train/test split, 3 runs per query, precision/recall/accuracy metrics, live HTML report | Manual process: write 5+5 queries, test mentally | skill-creator |
| **Plugin/distribution guidance** | `package_skill.py` produces .skill files | Full plugin architecture reference, marketplace distribution, cross-surface deployment | skill-architect |
| **Skill lifecycle** | Implicit (iterate until happy) | Explicit reference (maintenance, versioning, deprecation) | skill-architect |
| **Skill composition** | Not addressed | Dedicated reference for cross-skill dependencies and composition patterns | skill-architect |
| **Tone** | Conversational, warm, practical ("Cool? Cool.") | Authoritative, encyclopedic, structured | Preference-dependent |
| **SKILL.md line count** | ~480 lines | ~500 lines | Tie |
| **Total reference material** | ~1,200 lines across agents + schemas | ~3,000+ lines across 13 reference files | skill-architect |

---

## What skill-architect Does That skill-creator Does Not

### 1. Knowledge Engineering Framework

This is the single largest differentiator. skill-architect includes a full knowledge engineering reference (`references/knowledge-engineering.md`) that teaches you HOW to extract expert knowledge before you ever write a SKILL.md. Protocol Analysis, Repertory Grids, Critical Incident Technique, Concept Mapping -- these are real KE methods from the academic literature, cited with real-world examples (Boeing's ETS system, Flanagan's WWII pilot studies, Irish healthcare CIT studies). It also includes AI-native techniques like corpus distillation at $0.001/page.

skill-creator assumes you already know what your skill should do. skill-architect helps you figure that out.

### 2. Comprehensive Platform Reference

skill-architect documents every frontmatter field, every platform constraint, every common rejection cause, and the full extension taxonomy. It functions as a spec sheet. If you hit a parse error because you used `tools:` instead of `allowed-tools:`, skill-architect will tell you why. skill-creator won't.

### 3. Visual Artifact Guidance

skill-architect catalogs all 23 Mermaid diagram types with a use-case mapping table. It argues (correctly) that Mermaid serves dual audiences -- humans see rendered diagrams, agents read graph DSL that's more precise than prose. skill-creator never mentions visualization.

### 4. Shibboleth Encoding Framework

The shibboleth template (Novice/Expert/Timeline/LLM mistake/Detection) is a genuinely useful structure for capturing the expert knowledge that makes skills valuable rather than generic. skill-creator mentions "explain the why" but doesn't provide a formal structure for capturing domain-specific expertise.

### 5. Subagent Design Patterns

skill-architect includes guidance on designing skills that will be consumed by subagents -- three loading layers, prompt structure, output contracts. This is forward-looking: as multi-agent orchestration becomes standard, skills need to be machine-readable protocols, not just human-facing instructions.

### 6. Extension Taxonomy and Evolution Path

The Skill -> Skill + Scripts -> Skill + MCP -> Skill + Subagent -> Plugin evolution path is genuinely useful. It prevents the common mistake of building an MCP server when a script would suffice, or building a plugin when a skill is enough.

### 7. Scoring Rubric

A concrete 5-axis 0-10 rubric gives you a measurable target. skill-creator's quality assessment is implicit in its grading agents, but there's no standalone rubric you can apply without running the full eval pipeline.

---

## What skill-creator Does That skill-architect Does Not

### 1. Automated Eval Infrastructure (The Killer Feature)

This is the decisive advantage. skill-creator ships 8 working Python scripts that form a complete evaluation pipeline:

- `run_eval.py` -- spawns `claude -p` processes to test whether your skill triggers correctly
- `run_loop.py` -- automated description optimization with train/test split, precision/recall/accuracy metrics
- `aggregate_benchmark.py` -- statistical aggregation with mean/stddev/delta across configurations
- `improve_description.py` -- uses Claude with extended thinking to propose description improvements based on eval failures
- `generate_report.py` / `generate_review.py` -- HTML viewers for qualitative review and quantitative benchmarking
- `package_skill.py` -- packages skills into distributable .skill files
- `quick_validate.py` -- fast structural validation

skill-architect tells you to "write 5 queries that should trigger and 5 that shouldn't." skill-creator automates this into a loop that runs each query 3 times, computes trigger rates, splits train/test to prevent overfitting, and iterates until convergence. This is the difference between checking your work by reading it once and running a test suite.

### 2. Subagent-Based Testing

The grader, comparator, and analyzer agents form a quality assurance pipeline:

- **Grader**: Evaluates assertions against outputs with evidence-based pass/fail, extracts and verifies claims, critiques the evals themselves
- **Comparator**: Blind A/B comparison with structured rubrics to prevent bias
- **Analyzer**: Post-hoc analysis of WHY one version beat another, with actionable improvement suggestions

skill-architect has nothing comparable. It has a scoring rubric, but no mechanism to apply it automatically.

### 3. The Iteration Loop

skill-creator's core loop (draft -> test -> grade -> show human -> read feedback -> improve -> repeat) is a battle-tested methodology for converging on quality. The key insight: run with-skill AND baseline runs in the same turn, so you're always measuring the delta, not absolute quality.

skill-architect's iteration guidance is "After real-world use: notice struggles, improve SKILL.md." That's reasonable advice but not a methodology.

### 4. Writing Philosophy

skill-creator's writing guidance is more nuanced and humane:

> "Try hard to explain the **why** behind everything you're asking the model to do. Today's LLMs are *smart*. [...] If you find yourself writing ALWAYS or NEVER in all caps, or using super rigid structures, that's a yellow flag."

> "Rather than put in fiddly overfitty changes, or oppressively constrictive MUSTs, if there's some stubborn issue, you might try branching out and using different metaphors, or recommending different patterns of working."

This reflects hard-won wisdom about prompt engineering. skill-architect's writing advice is more mechanical ("Write in imperative form: 'To accomplish X, do Y'").

### 5. Audience Calibration

skill-creator explicitly addresses the fact that skill creators range from plumbers to senior engineers. It coaches the agent to read context cues and adjust jargon. skill-architect assumes a technically literate audience throughout.

### 6. Cross-Environment Support

skill-creator has explicit sections for Claude.ai, Claude Code, and Cowork environments, with adapted workflows for each. skill-architect doesn't address environment differences at all.

### 7. Generalization Wisdom

skill-creator's advice on avoiding overfitting to test cases is genuinely important:

> "We're trying to create skills that can be used a million times [...] across many different prompts. Here you and the user are iterating on only a few examples over and over again. [...] The user knows these examples in and out. But if the skill you and the user are codeveloping works only for those examples, it's useless."

This is the kind of meta-awareness that separates experienced practitioners from template followers.

---

## Detailed Analysis

### Where skill-architect Excels: Breadth and Depth of Reference Material

skill-architect is an encyclopedia. Its 13 reference files cover nearly every aspect of skill design, from knowledge engineering methodology to Mermaid diagram syntax to plugin distribution to skill lifecycle management. If you encounter an obscure problem (what happens when two skills compete for the same trigger? how do you design a skill for subagent consumption? what's the evolution path from script to MCP server?), skill-architect probably has a reference file for it.

The knowledge engineering reference is particularly valuable because it addresses the hardest part of skill creation: figuring out what knowledge to encode. Most people skip this step and jump straight to writing SKILL.md, which produces generic skills that could have been written by anyone who read the documentation for 20 minutes. The KE methods (Protocol Analysis, Repertory Grids, Critical Incident Technique) are real techniques from the academic literature, adapted for AI-native workflows.

### Where skill-creator Excels: Executable Methodology

skill-creator is a workshop, not a library. It doesn't just tell you what a good skill looks like -- it gives you tools to measure whether your skill IS good, and a loop to make it better. The description optimization pipeline alone (train/test split, 3 runs per query, precision/recall/accuracy metrics, live HTML report) is worth more than any amount of written guidance, because it converts "I think this description is good" into "this description triggers correctly 87% of the time on held-out queries."

The blind comparison system (comparator + analyzer agents) is genuinely clever. By giving two outputs to an independent agent without revealing which skill produced which, you eliminate bias and get honest quality assessments. This is the kind of methodology that academic researchers use to evaluate interventions, applied to skill development.

### The Fundamental Tension: Reference vs. Process

skill-architect answers: "What should a skill look like?"
skill-creator answers: "How do I know my skill works?"

These are complementary, not competing questions. The problem is that each skill treats its answer as sufficient. skill-architect assumes that if you follow its templates and checklists, you'll produce a good skill. skill-creator assumes that if you iterate on test cases with human feedback, you'll converge on quality.

Both assumptions are partially wrong:

- Following templates without testing produces skills that look right but might not activate correctly or produce useful outputs.
- Iterating without deep domain knowledge produces skills that pass benchmarks but lack the expert insight that makes them genuinely valuable.

### Quality of the SKILL.md Itself

**skill-creator** reads like a conversation with a thoughtful senior engineer. It's warm, practical, acknowledges uncertainty, and adapts to context. The writing style section is genuinely good advice for anyone writing prompts. But it's also somewhat rambling -- it repeats the core loop three times (once in the intro, once in detail, once at the end "for emphasis"), and some sections feel like they were added incrementally rather than designed holistically.

**skill-architect** reads like a technical specification. It's dense, well-structured, and comprehensive. The progressive disclosure architecture is well-practiced -- the SKILL.md itself demonstrates the pattern by keeping core concepts concise and pointing to references for depth. But it can feel overwhelming, and some of its guidance is prescriptive to the point of rigidity (e.g., demanding Mermaid diagrams for every process, insisting on the shibboleth template for every anti-pattern).

### The Scripts Gap

skill-creator ships 8 Python scripts and 2 HTML templates. These are real, working tools that automate the hardest parts of skill development: testing activation, benchmarking quality, optimizing descriptions, and packaging for distribution.

skill-architect ships 1 Python script (validate_mermaid.py) and references 2 others (validate_skill.py, check_self_contained.py) that don't appear to exist in the skill directory. This is ironic given that skill-architect's own anti-pattern #4 is "Phantom Tools" -- referencing files that don't exist.

### The Originality Gap

skill-architect contains a significant amount of original intellectual contribution that goes beyond what either skill or the official documentation provides:

1. The knowledge engineering framework is novel in this context
2. The extension taxonomy and evolution path is a genuine organizational contribution
3. The shibboleth template captures something real about expert knowledge
4. The visual artifacts catalog is the most comprehensive Mermaid reference I've seen in a skill

skill-creator's originality lies more in its methodology (the eval loop, blind comparison, description optimization) than in its written content. The content is solid but doesn't break new conceptual ground -- it's a well-engineered process for skill development.

---

## Verdict

### If I were building a skill from scratch, which would I want?

**Both. In sequence.**

But if forced to choose one:

**For a beginner or someone building their first 1-5 skills**: skill-creator wins. Its eval infrastructure and iteration loop will teach you more about what makes a good skill than any amount of reading. You'll discover through testing that your description is too vague, your instructions are ambiguous, and your output contract is underspecified. The human-in-the-loop review cycle is the fastest path to a working skill.

**For an experienced skill builder working on high-value domain skills**: skill-architect wins. Once you know the mechanics of skill creation, the bottleneck shifts from "can I write a valid SKILL.md" to "can I encode the deep expertise that makes this skill worth using." The knowledge engineering framework, shibboleth templates, and extension taxonomy become essential. You already know how to test -- you need to know what to test.

**For building the best possible skill**: Use skill-architect's knowledge engineering methods and reference material to DESIGN the skill, then use skill-creator's eval infrastructure to TEST and ITERATE on it. This is, in fact, what the skill-architect's own `pairs-with` metadata suggests:

```yaml
pairs-with:
  - skill: skill-creator
    reason: The architect designs skill structure; the creator guides implementation following those patterns
```

### The Honest Assessment

skill-creator is the better-engineered skill. It ships working tools. Its methodology is battle-tested. Its writing advice is more nuanced. It handles edge cases (Claude.ai, Cowork, non-technical users). It practices what it preaches.

skill-architect is the more intellectually ambitious skill. It covers more ground, goes deeper on design principles, and includes genuinely original frameworks (knowledge engineering, extension taxonomy, shibboleth templates). But it has phantom tool references, is denser than it needs to be, and doesn't provide automated ways to verify its own guidance.

The irony: skill-architect would score itself higher on its own rubric (more anti-patterns, deeper expertise, better progressive disclosure), but skill-creator would perform better in skill-creator's eval loop (its skills actually work, its descriptions actually trigger, its outputs are actually measurable).

**If I had to pick one to guide my next skill**: skill-creator. Not because it knows more, but because it helps me discover what I don't know through testing rather than reading. The eval loop is the closest thing to empirical skill science that exists.

**If I were designing a skill creation CURRICULUM**: skill-architect first (learn the theory), skill-creator second (apply and measure it).

### Final Score

| Criterion | skill-creator | skill-architect |
|---|---|---|
| Practical utility for first-time builders | 9/10 | 6/10 |
| Depth of design guidance | 6/10 | 9/10 |
| Working tooling | 9/10 | 3/10 |
| Intellectual contribution | 7/10 | 9/10 |
| Self-consistency (practices what it preaches) | 8/10 | 6/10 |
| Completeness of platform coverage | 8/10 | 9/10 |
| Iteration methodology | 10/10 | 4/10 |
| Knowledge extraction guidance | 2/10 | 10/10 |
| **Overall** | **7.4/10** | **7.0/10** |

Close. Different strengths. Better together than apart.
