# Description & Frontmatter Audit: skill-architect

**Evaluator**: skill-creator methodology
**Target**: `/Users/erichowens/.claude/skills/skill-architect/SKILL.md`
**Date**: 2026-03-06
**Focus**: Description triggering quality, frontmatter field usage, activation behavior

---

## Overall Score: 8/10

The skill-architect has a strong, well-structured frontmatter and a description that follows its own recommended formula. It is among the better descriptions I have seen in practice. However, there are specific issues that prevent a 9 or 10 -- primarily around description length, slight formula deviations, and a few frontmatter decisions that could be tighter.

---

## 1. Description Analysis

### 1.1 The Actual Description

```yaml
description: Design, create, audit, and improve Claude Agent Skills with expert-level
  progressive disclosure. Use when building new skills, reviewing existing skills,
  debugging activation failures, encoding domain expertise, designing skills for
  subagent consumption, or understanding platform constraints and distribution
  surfaces. NOT for general Claude Code features, runtime debugging, non-skill
  coding, or MCP server implementation.
```

### 1.2 Formula Compliance

The skill-creator methodology recommends: `[What it does] [When to use it -- be slightly pushy]. NOT for [Exclusions].`

| Component | Present? | Quality |
|-----------|----------|---------|
| What it does | Yes | "Design, create, audit, and improve Claude Agent Skills with expert-level progressive disclosure" |
| When to use | Yes | "Use when building new skills, reviewing existing skills, debugging activation failures..." |
| NOT clause | Yes | "NOT for general Claude Code features, runtime debugging, non-skill coding, or MCP server implementation" |

**Verdict**: All three components present. This is structurally correct.

### 1.3 Strengths

1. **Verb-rich opening**: "Design, create, audit, and improve" -- four specific verbs that map directly to user actions. A user who types "create a skill" or "audit my skill" will semantically match.

2. **Domain noun specificity**: "Claude Agent Skills" -- not vague. Not "helps with skills" or "skill-related tasks." Names the exact artifact.

3. **Pushy "Use when" clause**: Lists six specific trigger scenarios. This combats Claude's undertriggering tendency effectively. The scenarios cover: creation, review, debugging, encoding expertise, subagent design, and platform constraints.

4. **NOT clause with four exclusions**: Each exclusion is a plausible false-positive scenario. "MCP server implementation" is particularly good -- it prevents activation when someone is building an MCP server (related but distinct from skill creation).

5. **Name-description alignment**: The name "skill-architect" and the description both center on skill design/creation. No mismatch.

### 1.4 Weaknesses

1. **Description is 56 words / ~370 characters**: This falls at the upper end of the ideal range (25-50 words per the description-guide.md). It is not over the 1024-character limit, but it is dense. The six-item "Use when" list borders on a mini-manual. Per the skill-creator's guidance, process details belong in the SKILL.md body, not the description.

2. **"expert-level progressive disclosure" is jargon in the What clause**: A user searching for help creating a skill is unlikely to think in terms of "progressive disclosure." This phrase describes HOW the skill works rather than WHAT the user gets. It is architect-internal vocabulary. Compare: "with expert-level progressive disclosure" vs. "following best practices for activation, structure, and reusability." The latter maps more closely to what users would type.

3. **The "Use when" list is slightly exhaustive**: Six trigger scenarios in the description is on the high side. The description-guide.md warns against mini-manuals. The first three triggers (building, reviewing, debugging) are the 80% case. The latter three (encoding domain expertise, designing for subagent consumption, understanding platform constraints) are advanced scenarios that could live in the SKILL.md body's "When to Use" section instead. Keeping 3-4 triggers in the description and deferring the rest would sharpen activation.

4. **"distribution surfaces" is unclear**: The phrase "understanding platform constraints and distribution surfaces" uses terminology that a user would never type. What is a "distribution surface"? This is expert-speak that harms semantic matching. A user would say "how do I share my skill" or "how do I publish a skill," not "distribution surfaces."

5. **Missing trigger keyword: "SKILL.md"**: Many users will say "help me write a SKILL.md" or "review my SKILL.md." The description does not contain this literal term, relying on semantic inference from "Claude Agent Skills." Given that Claude evaluates semantically, this is partially mitigated, but including the exact artifact name would strengthen matching for the most common phrasing.

### 1.5 Activation Simulation

Testing 10 queries against this description:

**Should trigger (5/5 expected matches)**:

| Query | Would it trigger? | Confidence |
|-------|-------------------|------------|
| "Create a new skill for code review" | Yes | High -- "create" + "skill" directly match |
| "Audit my database-migration skill" | Yes | High -- "audit" is in the opening verbs |
| "My skill isn't activating, help me fix it" | Yes | Medium -- "debugging activation failures" covers this, but the user didn't say "activation failure" |
| "I want to encode my React expertise into a skill" | Yes | High -- "encoding domain expertise" is explicit |
| "Review this SKILL.md for quality" | Likely yes | Medium -- "reviewing existing skills" covers it, though "SKILL.md" is not in the description |

**Should NOT trigger (5/5 expected non-matches)**:

| Query | Would it trigger? | Confidence |
|-------|-------------------|------------|
| "Build an MCP server for Slack" | No | High -- "NOT for MCP server implementation" |
| "Debug my Python script" | No | High -- "NOT for non-skill coding" |
| "How do I use Claude Code slash commands?" | No | High -- "NOT for general Claude Code features" |
| "Review this PR for TypeScript errors" | No | High -- clearly code review, not skill review |
| "Help me design a plugin for distribution" | Uncertain | Low -- "distribution surfaces" is in the description, and plugins are covered in the body. This is a borderline case that could false-positive. The NOT clause does not exclude plugin work. |

**Score**: 4.5/5 triggers work, 4.5/5 non-triggers work. The edge case is plugin design, which this skill does cover in its body (extension taxonomy section). That is arguably correct activation, making this closer to 5/5 on both sides.

**Activation Precision**: 9/10

### 1.6 Comparison to skill-creator's Own Description

```yaml
# skill-creator
description: Guide for creating effective skills. This skill should be used when
  users want to create a new skill (or update an existing skill) that extends
  Claude's capabilities with specialized knowledge, workflows, or tool integrations.
```

Comparing the two:

| Criterion | skill-creator | skill-architect |
|-----------|---------------|-----------------|
| Verb specificity | "Guide for creating" (1 verb) | "Design, create, audit, improve" (4 verbs) |
| NOT clause | Missing entirely | Present with 4 exclusions |
| Trigger keywords | "create a new skill", "update an existing skill" | 6 scenarios listed |
| Jargon level | Low (accessible) | Medium-high ("progressive disclosure", "distribution surfaces") |
| Third person | Yes ("This skill should be used when") | No (imperative: "Use when") |
| Word count | ~30 words | ~56 words |

**Key observation**: The skill-creator lacks a NOT clause -- which violates its own guidance. The skill-architect is more rigorous here. However, the skill-creator is more concise and accessible, while the architect is denser and more jargon-laden.

The skill-creator recommends third-person ("This skill should be used when...") while the skill-architect uses imperative ("Use when..."). The architect's own description-guide.md does not mandate third person -- it focuses on content, not voice. This is a minor stylistic divergence, not a defect.

---

## 2. Frontmatter Field Audit

### 2.1 Fields Used

```yaml
name: skill-architect
description: [56-word description]
allowed-tools: Read,Write,Edit,Bash,Grep,Glob
argument-hint: '[skill-path-or-name] [action: create|audit|improve|debug]'
metadata:
  category: Productivity & Meta
  tags: [architect, create-skill, improve-skill, skill-audit]
  pairs-with:
    - skill: skill-creator
      reason: [...]
    - skill: skill-grader
      reason: [...]
    - skill: skill-documentarian
      reason: [...]
```

### 2.2 Required Fields

| Field | Present | Valid | Notes |
|-------|---------|-------|-------|
| `name` | Yes | Yes | Lowercase-hyphenated, 15 chars, no reserved words |
| `description` | Yes | Yes | Under 1024 chars, no XML tags |

Both required fields are present and valid. No issues.

### 2.3 Optional Fields Assessment

**`allowed-tools: Read,Write,Edit,Bash,Grep,Glob`**

This is a broad permission set. The skill-architect's own guidance says to use "least privilege." Let us evaluate:

- `Read,Grep,Glob` -- needed for reading/searching skill files. Justified.
- `Write,Edit` -- needed for creating/modifying SKILL.md and reference files. Justified.
- `Bash` -- needed for running validation scripts (`validate_skill.py`, `validate_mermaid.py`, `init_skill.py`). Justified.

However, `Bash` is unscoped. The architect's own tool permission table says: "Never for untrusted: Unrestricted Bash." A scoped version like `Bash(python:*,wc:*)` would be more consistent with the skill's own teaching. This is a "do as I say, not as I do" issue.

**Severity**: Low. The skill-architect is user-invoked (not auto-triggered in untrusted contexts), so the risk is minimal. But it sets a bad example for skills it creates.

**`argument-hint: '[skill-path-or-name] [action: create|audit|improve|debug]'`**

Good use of this field. The hint communicates:
1. First argument: a path or skill name
2. Second argument: one of four actions

This enables autocomplete UX and sets expectations. The four actions (create, audit, improve, debug) map to the four verbs in the description. Consistent.

**`metadata.category: Productivity & Meta`**

Custom key, ignored by runtime. Useful for gallery/dashboard tooling. Appropriate category choice -- this is a meta-skill about creating other skills.

**`metadata.tags: [architect, create-skill, improve-skill, skill-audit]`**

Custom key, ignored by runtime. Tags are reasonable but note: tags do NOT influence activation. They are purely for external tooling. The tag "architect" is redundant with the name. "create-skill" and "improve-skill" duplicate verbs already in the description. This is harmless but not adding value for activation.

**`metadata.pairs-with`**

Three pairings declared:
1. `skill-creator` -- complementary (architect designs structure, creator implements)
2. `skill-grader` -- complementary (grading identifies weaknesses for architect to fix)
3. `skill-documentarian` -- complementary (documentation standards + architecture)

These are well-reasoned pairings with clear, non-trivial reasons. The architect both teaches about `pairs-with` and practices it. Good consistency.

### 2.4 Missing Optional Fields Worth Considering

| Field | Why Consider It |
|-------|-----------------|
| `disable-model-invocation: false` | Not needed (default is false), but could be explicit for a meta-skill that benefits from auto-triggering |
| `context: fork` | A meta-skill like this could benefit from forked execution -- auditing a skill in isolation without contaminating the main conversation. Worth experimenting with. |
| `license` | The skill-creator has a license field. The architect does not. If this is intended for distribution, a license is recommended. |

### 2.5 Invalid/Problematic Fields

None found. All keys used are valid per the architect's own documentation.

---

## 3. Cross-Referencing Against skill-creator's Methodology

The skill-creator's process has 6 steps. Let me evaluate how well the architect's frontmatter aligns with the creator's recommendations:

### Step 1: Understanding with Concrete Examples

The architect's SKILL.md includes a "When to Use" section with explicit trigger and non-trigger lists. This is the output of Step 1. The description reflects these examples well.

### Step 4: Edit the Skill -- Metadata Quality

The skill-creator says: "The name and description in YAML frontmatter determine when Claude will use the skill. Be specific about what the skill does and when to use it. Use the third-person (e.g. 'This skill should be used when...' instead of 'Use this skill when...')."

**Finding**: The skill-architect uses imperative voice ("Use when building...") instead of third-person ("This skill should be used when building..."). This is a stylistic departure from skill-creator's recommendation. Impact on activation is likely negligible -- Claude's semantic matching cares about content, not grammatical person -- but it is a deviation from the reference methodology.

### Step 5: Packaging -- Validation

The skill-creator's `quick_validate.py` checks:
1. SKILL.md exists -- Pass
2. Frontmatter has `---` delimiters -- Pass
3. `name:` present -- Pass
4. `description:` present -- Pass
5. Name is hyphen-case -- Pass ("skill-architect" matches `^[a-z0-9-]+$`)
6. No angle brackets in description -- Pass

The architect would pass the creator's validation. However, the creator's validation is minimal -- it does not check for NOT clauses, description length, or name-description alignment. The architect's own validation scripts (`validate_skill.py`) presumably check more.

---

## 4. Detailed Findings

### 4.1 Critical Issues (Must Fix)

None. The description and frontmatter are functional, follow the formula, and would activate correctly in the vast majority of cases.

### 4.2 Significant Issues (Should Fix)

1. **Trim the "Use when" list from 6 to 3-4 items in the description**. Move "encoding domain expertise," "designing skills for subagent consumption," and "understanding platform constraints and distribution surfaces" to the SKILL.md body's "When to Use" section. They are already there. Keeping them in the description makes it a mini-manual.

   **Suggested revision**:
   ```yaml
   description: Design, create, audit, and improve Claude Agent Skills with
     expert-level structure and activation precision. Use when building new
     skills, reviewing existing skills for quality, or debugging why a skill
     fails to activate. NOT for general Claude Code features, runtime
     debugging, non-skill coding, or MCP server implementation.
   ```
   This is 42 words (vs. 56), hits the ideal 25-50 range, and keeps the three highest-frequency triggers.

2. **Replace "progressive disclosure" with user-facing language**. "Progressive disclosure" is the architect's internal design philosophy. The user cares about the outcome: well-structured, efficiently-loading skills. Suggested: "expert-level structure and activation precision."

3. **Replace "distribution surfaces" with plain language**. If this trigger scenario stays in the description, rephrase to "publishing or sharing skills across Claude.ai, API, and Claude Code." But per item 1, this should move to the body.

### 4.3 Minor Issues (Nice to Fix)

1. **Scope the `Bash` permission**. Change `Bash` to `Bash(python:*,wc:*,mkdir:*)` or similar. The architect teaches least privilege but does not practice it.

2. **Consider adding "SKILL.md" as a keyword in the description**. Many users will literally say "help me write a SKILL.md." The semantic matching will probably catch this, but including the literal term improves matching confidence.

3. **Add `license` field**. The paired skill-creator includes a license. For consistency and distribution readiness, add one.

4. **Third-person voice**: The skill-creator recommends "This skill should be used when..." The architect uses "Use when..." This is a minor stylistic inconsistency. Both work for activation. If the architect wants to model its own teachings perfectly, it could match the creator's recommendation -- but this is low-priority.

---

## 5. Comparative Assessment

### How skill-architect's Description Compares to Best Practices

| Best Practice (from description-guide.md) | Score |
|-------------------------------------------|-------|
| Contains specific verbs | 10/10 -- four verbs |
| Names a specific deliverable or domain | 9/10 -- "Claude Agent Skills" is specific; "distribution surfaces" is vague |
| Specific and context-rich | 8/10 -- rich but slightly over-dense |
| Has NOT clause with 2-5 exclusions | 10/10 -- four exclusions |
| Name-description aligned | 10/10 |
| Under 1024 chars | 10/10 (~370 chars) |
| No process/workflow details in description | 8/10 -- the 6-item "Use when" list approaches process territory |
| No overlap with other skills | 8/10 -- some overlap with skill-creator is intentional (pairs-with), but could cause competition |

**Average**: 9.1/10 on the checklist.

### Overlap Concern: skill-architect vs. skill-creator

Both skills trigger on "create a skill." The architect's description says "create" and "building new skills." The creator's description says "creating effective skills." This is intentional overlap -- they pair together. But in practice, Claude may activate one or the other semi-randomly. The `pairs-with` field does not influence runtime selection; it is metadata only.

**Recommendation**: The architect should differentiate more clearly. The architect focuses on *structure, architecture, and design decisions*. The creator focuses on *step-by-step implementation workflow*. The architect's description could lean harder into "architecture" language: "Architect the structure of Claude Agent Skills" rather than "Design, create..." to reduce overlap.

---

## 6. Summary

| Category | Score | Notes |
|----------|-------|-------|
| Formula compliance | 9/10 | All three components present; slightly verbose |
| Activation precision | 9/10 | Strong triggers, strong exclusions, one edge case |
| Frontmatter correctness | 9/10 | All fields valid, good use of optional fields |
| Least-privilege consistency | 6/10 | Unscoped Bash contradicts own teaching |
| Jargon / accessibility | 7/10 | "Progressive disclosure" and "distribution surfaces" are insider terms |
| Overlap management | 7/10 | Intentional overlap with skill-creator, but needs sharper differentiation |

**Composite: 8/10** -- A strong description and frontmatter that follows the formula, activates correctly, and uses optional fields well. The main improvements are: trim the description to 40-45 words, replace jargon with user-facing language, scope the Bash permission, and differentiate more sharply from skill-creator.
