# Run 4: Writing Style and Tone Evaluation

**Score: 5/10**

**Evaluator perspective**: Anthropic's skill-creator methodology
**Target**: skill-architect (SKILL.md, 500 lines)
**Criteria**: Explain the why not just the what; avoid heavy-handed MUSTs; use theory of mind; keep prompts lean

---

## Summary

The skill-architect is a competent reference document masquerading as a skill. It tells the agent *what* to do in exhaustive detail but rarely *why* any of it matters. It relies on rigid rules and tables where reasoning and trust would serve better. It is not lean -- it fills its entire 500-line budget without earning most of that space, because much of the content is enumeration (all 23 Mermaid types, all frontmatter keys, all platform constraints) rather than instruction that actually changes behavior. The writing is professional and well-organized, but it reads like a spec, not like guidance from someone who understands how an LLM reasons.

---

## Detailed Findings

### 1. Explaining the Why (Weak -- the biggest gap)

The skill-creator's own guidance on this point is unambiguous:

> "Try hard to explain the **why** behind everything you're asking the model to do. Today's LLMs are *smart*. They have good theory of mind and when given a good harness can go beyond rote instructions and really make things happen."

The skill-architect consistently violates this. It states rules without reasoning:

- "Keep SKILL.md under 500 lines. Move depth to `/references`." -- Why 500? What goes wrong at 600? What cognitive effect does length have on the consuming agent? The architect never says. A model reading this either obeys blindly or, worse, ignores it because it doesn't understand the stakes.

- "Never instruct 'read all reference files before starting.' Instead: 'Read only the files relevant to the current step.'" -- This is a good rule, but the architect doesn't explain that eager loading wastes context window, that agents with large loaded contexts tend to lose focus, or that selective loading lets the agent stay lean and responsive. Without the why, it's just another imperative.

- "Write in imperative form: 'To accomplish X, do Y' not 'You should do X.'" -- Why? Imperative form is not obviously better. The architect could explain that it reduces ambiguity, that models follow direct instructions more reliably than suggestions, or that "you should" creates hedging room the agent will exploit. It says none of this.

- The entire "Platform Constraints" section is pure enumeration (name length 64 chars, upload size 8MB, etc.) with zero reasoning. These facts are useful, but they sit there like a specification sheet rather than guidance. A line like "Names over 64 chars get silently truncated, which means your skill won't match and you'll spend an hour debugging activation" would make the constraint *stick*.

There are a few places where the architect does explain why -- the Description Formula section is the best example. "Claude also tends to **undertrigger** -- it errs toward NOT activating skills. Combat this by making descriptions slightly pushy" is excellent. It explains the mechanism, the consequence, and the mitigation in one sentence. The skill needs much more of this quality throughout.

### 2. Heavy-Handed MUSTs and Rigidity (Moderate problem)

The skill-creator warns:

> "If you find yourself writing ALWAYS or NEVER in all caps, or using super rigid structures, that's a yellow flag -- if possible, reframe and explain the reasoning so that the model understands why the thing you're asking for is important."

The architect doesn't use "MUST" in all caps (credit where due), but it achieves the same rigidity through a different mechanism: dense tables of rules presented as absolute requirements with no escape hatches.

Examples of rigid framing without reasoning:

- "SKILL.md **must** be <500 lines" (line 77) -- presented as a hard constraint with the word "must"
- "Critical rules" (line 76) -- the framing implies that violating any of these is a serious error, but no explanation of severity or tradeoff
- The Validation Checklist (lines 429-444) uses checkbox format, which inherently suggests every item is mandatory. Some of these are critical (frontmatter has name + description) and some are stylistic preferences (processes use Mermaid diagrams). Treating them identically flattens their importance.

The Anti-Pattern Summary table (lines 410-423) is another case. "Fix" implies there's one right answer. But "Documentation Dump -> Decision trees in SKILL.md, depth in /references" isn't always the fix. Sometimes a documentation dump is appropriate for a reference-heavy domain. The architect doesn't acknowledge that context matters.

Compare this to the skill-creator's own tone: "These word counts are approximate and you can feel free to go longer if needed." That single sentence accomplishes what the architect's rigid 500-line rule cannot: it sets a target while trusting the agent's judgment. The architect never trusts.

### 3. Theory of Mind (Weak)

The skill-creator explicitly calls out theory of mind in two dimensions:

First, understanding how the LLM (the consumer of the skill) thinks:

> "Today's LLMs are smart. They have good theory of mind and when given a good harness can go beyond rote instructions and really make things happen."

The architect writes for a model that needs to be told every detail and can't be trusted to reason. It provides 23 Mermaid diagram types in a table because it doesn't trust the model to know them or look them up. It provides a complete list of invalid frontmatter keys because it doesn't trust the model to infer that "tools" isn't "allowed-tools." This is the opposite of theory-of-mind design -- it's rote-instruction design.

Second, understanding the human user:

The skill-creator has a lovely section about adjusting language based on user sophistication:

> "There's a trend now where the power of Claude is inspiring plumbers to open up their terminals, parents and grandparents to google 'how to install npm'."

The architect shows zero awareness of audience adaptation. It uses terms like "branded types," "progressive disclosure," "shibboleths," and "shibboleth template" without ever pausing to consider whether the reader knows these terms. "Shibboleth" is a particularly strong choice -- it's a word that is itself a shibboleth. Someone who doesn't know it will feel excluded. Someone who does will appreciate it. But the architect never explains it (ironic, given that the whole section is about encoding expert knowledge).

### 4. Leanness (Poor -- the most quantifiable problem)

The skill-creator says:

> "Keep the prompt lean. Remove things that aren't pulling their weight."

The architect is 500 lines. It uses every line of its own budget. Let's examine what's actually pulling weight:

**High-value sections (keep):**
- Philosophy (4 lines) -- sets the frame efficiently
- Description Formula (lines 148-164) -- concrete, actionable, with good/bad examples
- The 6-Step Creation Process (lines 200-258) -- clear workflow
- Progressive Disclosure Architecture (lines 66-81) -- core concept, well-explained

**Low-value sections (candidates for /references or deletion):**
- All 23 Mermaid Diagram Types table (lines 298-326) -- 28 lines of enumeration. The agent either knows Mermaid or it doesn't. A single line ("Use the most specific Mermaid diagram type for your content -- flowcharts for decisions, state diagrams for lifecycles, sequence diagrams for protocols") would suffice in SKILL.md. The full table belongs in references/visual-artifacts.md (which already exists!).

- Platform Constraints table (lines 130-144) -- 14 lines of specification. Move to a reference file. The agent doesn't need to memorize upload size limits until it's actually uploading.

- Common Rejection Causes table (lines 450-464) -- 14 lines that overlap heavily with the Anti-Pattern Summary. Having both is redundant.

- Frontmatter Optional Fields table (lines 96-111) -- 15 lines listing every optional field. Most skills use 2-3 of these. This is reference material, not guidance.

- Invalid Keys section (lines 119-126) -- 7 lines of "don't use these wrong names." This is the kind of thing a validation script catches. Including it in the prompt is defensive programming against the LLM.

Conservative estimate: 80-100 lines could be moved to references without losing any behavioral value. That would bring the skill to ~400 lines and let the remaining content breathe.

### 5. Tone and Voice

The architect's voice is that of an authoritative technical specification. It's consistent, clear, and well-structured. But it's cold. There is no personality, no warmth, no conversational asides. Compare:

**Skill-creator**: "Cool? Cool." / "This task is pretty important (we are trying to create billions a year in economic value here!)" / "Good luck!"

**Skill-architect**: Nothing comparable. The closest it gets is "Skills are the knowledge. Agents are the execution. Skills make agents experts." which is punchy but still reads like a tagline, not a human voice.

This matters because tone affects how an LLM engages with instructions. Warm, confident, trusting instructions tend to produce warm, confident, trusting behavior. Rigid, specification-heavy instructions tend to produce rigid, specification-following behavior. The architect is calibrating the agent toward the latter, which may not be what users of meta-skills want.

### 6. What the Architect Does Well

To be fair, several things work:

- **Organization is excellent.** The progressive disclosure concept is well-applied to its own structure. Tables are used effectively for lookup-style information. Sections flow logically.
- **The Description Formula section is the standout.** It explains why (semantic matching, undertriggering), gives concrete good/bad examples, and provides a clear pattern. More of the skill should be written at this level.
- **The template (lines 169-196) is clean and practical.** It gives just enough structure without being prescriptive.
- **Anti-pattern format (Novice/Expert/Timeline)** is a genuinely useful framework for encoding domain knowledge. It's one of the architect's original contributions.

---

## Recommendations (Prioritized)

1. **Add "why" to every rule.** Go through each imperative and add one sentence of reasoning. "Keep SKILL.md under 500 lines" becomes "Keep SKILL.md under 500 lines -- longer skills dilute the agent's attention and the most critical instructions get lost in noise." This is the single highest-leverage change.

2. **Move enumeration to references.** The 23 Mermaid types, full optional frontmatter list, platform constraints, and common rejection causes all belong in reference files. The SKILL.md should say "23 Mermaid diagram types are available -- see references/visual-artifacts.md" and move on.

3. **Soften rigid rules into calibrated guidance.** Replace "SKILL.md must be <500 lines" with "Aim for under 500 lines. If you're pushing past that, it's a signal that some content should move to references -- but a 520-line skill with tight reasoning beats a 400-line skill with gaps." Trust the agent's judgment.

4. **Add a sentence explaining "shibboleth."** The term is central to the skill's value proposition but never defined. A parenthetical would suffice: "shibboleths (expert knowledge markers that distinguish real practitioners from surface-level imitators)."

5. **Inject occasional voice.** Not forced humor, but warmth. The Philosophy section is a good candidate: "Great skills are progressive disclosure machines" could expand to "Great skills are progressive disclosure machines. The agent gets what it needs when it needs it -- not a wall of text at activation that it'll mostly ignore."

6. **Deduplicate.** The Anti-Pattern Summary and Common Rejection Causes tables share conceptual territory. Merge them or clearly differentiate their purposes.

---

## Bottom Line

The skill-architect knows the domain deeply and organizes its knowledge well. But it writes like a specification when it should write like a mentor. It tells instead of teaching. It enumerates instead of explaining. It constrains instead of guiding. By the skill-creator's own standards -- explain the why, avoid rigid MUSTs, use theory of mind, stay lean -- the architect earns a 5/10. The knowledge is there; the delivery needs a rewrite that trusts the model more and the checklist less.
